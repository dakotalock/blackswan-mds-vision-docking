"""Offline closed-loop check of the navigation filter + guidance (no MDS needed): Clohessy-Wiltshire truth,
measurement noise matching the pose-estimator accuracy measured on real MDS frames, a camera dropout and a
thruster misfire. Run: python tests/test_offline_closed_loop.py"""
import os, sys
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "examples"))
from utilities.util_vision_nav import Guidance, RelNavFilter, cw_stm  # noqa: E402

N = 3.986004418e14 ** 0.5 / 7630e3 ** 1.5


def truth_step(x, a, dt):
    F = cw_stm(N, dt); B = np.vstack([0.5 * dt * dt * np.eye(3), dt * np.eye(3)])
    return F @ x + B @ a


def run(seed, start=14.0, dropout=None, misfire=None, vision_period=3.0, max_t=600):
    rng = np.random.default_rng(seed)
    axis = np.array([0.0, -1.0, 0.0]) + rng.normal(0, 0.02, 3); axis /= np.linalg.norm(axis)   # port faces -V
    lat = rng.normal(0, 0.06 * start, 3); lat -= axis * (lat @ axis)
    x = np.concatenate([axis * start + lat, rng.normal(0, 0.005, 3)])
    nav = RelNavFilter(N, np.concatenate([x[:3] + rng.normal(0, 1.0, 3), np.zeros(3)]), 2.0, 0.05)
    g = Guidance(); t, last_fix, next_v, dv = 0.0, -1e9, 0.0, 0.0
    while t < max_t:
        if t >= next_v:
            next_v = t + vision_period
            r = np.linalg.norm(x[:3])
            if not (dropout and dropout[0] <= t < dropout[1]) and r > 2.7:     # below 2.7 m the marker leaves the view (as in MDS)
                sigma = 0.01 + 0.0015 * r ** 2 if r > 10 else 0.01 + 0.002 * r    # measured on MDS frames
                if nav.update_position(x[:3] + rng.normal(0, sigma, 3), sigma):
                    last_fix = t
        along = x[:3] @ axis
        if along < 0.05:
            lat_err = np.linalg.norm(x[:3] - along * axis); speed = np.linalg.norm(x[3:])
            return dict(ok=lat_err < 0.10 and speed < 0.06, t=t, lateral_cm=lat_err * 100, speed_cms=speed * 100, dv=dv, events=g.events)
        a = g.command(t, nav.x, axis, N, t - last_fix, nav.pos_sigma)
        a_true = a * 1.02 + rng.normal(0, 2e-5, 3)
        if misfire and misfire[0] <= t < misfire[0] + 1:
            a_true = a_true + np.array(misfire[1])
        x = truth_step(x, a_true, 1.0); nav.predict(1.0, a); dv += np.linalg.norm(a); t += 1.0
    return dict(ok=False, t=t, reason="timeout", events=g.events, dv=dv)


if __name__ == "__main__":
    fails = 0
    res = [run(s) for s in range(50)]
    ok = [r for r in res if r["ok"]]
    print(f"Monte Carlo, 50 runs from 14 m: {len(ok)}/50 docked; mean time {np.mean([r['t'] for r in ok]):.0f} s; "
          f"mean miss {np.mean([r['lateral_cm'] for r in ok]):.1f} cm; mean contact speed {np.mean([r['speed_cms'] for r in ok]):.1f} cm/s; "
          f"mean dv {np.mean([r['dv'] for r in ok]):.3f} m/s; worst time {max(r['t'] for r in res):.0f} s")
    fails += len(ok) < 50
    d = run(3, dropout=(60, 120)); print("camera dropout 60-120 s:", d["ok"], d.get("events"), f"{d['t']:.0f} s")
    fails += not d["ok"]
    m = run(4, misfire=(40, [0.08, 0.0, 0.05])); print("thruster misfire at 40 s:", m["ok"], m.get("events"), f"{m['t']:.0f} s")
    fails += not m["ok"]
    print("ALL PASSED" if not fails else f"{fails} FAILED")
    sys.exit(1 if fails else 0)
