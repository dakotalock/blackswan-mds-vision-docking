// End to end in Node, no browser: ray-traced camera images -> the web version's ArUco detector -> pose -> Kalman
// filter -> guidance -> docking. Same loop as the browser page, with a synthetic camera instead of three.js.
// Run: node tests/test_web_closed_loop.mjs
import { readFileSync } from "node:fs";
import { detectMarker } from "../web/src/aruco.js";
import { mul, mulVec, seeded, transpose, v3 } from "../web/src/linalg.js";
import { Mission, R_LT } from "../web/src/mission.js";
import { renderMarker } from "./synthetic_camera.mjs";

const cal = JSON.parse(readFileSync(new URL("../web/data/calibration.json", import.meta.url)));
const pixRng = seeded(99);
function camera(camPos, R_cam) {                   // camera position and OpenCV axes in LVLH -> detected corners
  const R_Lm = mul(R_LT, cal.R_target_marker);     // marker frame -> LVLH (target body at the origin)
  const R_cm = mul(transpose(R_cam), R_Lm);
  const t_cm = mulVec(transpose(R_cam), v3.sub(mulVec(R_LT, cal.marker_center_target), camPos));
  const K = mission.cam.K;
  const g = renderMarker(K, 640, 480, cal.marker_side_m, R_cm, t_cm, pixRng);
  const d = detectMarker(g, 640, 480);
  return { corners: d ? d.corners : null };
}

let fails = 0;
let mission;
for (const [name, opts, expect] of [
  ["nominal, 10 m", { seed: 2 }, (s) => s.docked?.ok],
  ["camera dropout 30-70 s", { seed: 5, dropout: [30, 70] }, (s) => s.docked?.ok && s.events.some((e) => e[1] === "ABORT")],
  ["thruster misfire at 20 s", { seed: 4, misfire: [20, [0.08, 0, 0.05]] }, (s) => s.docked?.ok],
]) {
  mission = new Mission(cal, opts, camera);
  const t0 = Date.now();
  while (!mission.done) mission.step();
  const s = mission.summary(), d = s.docked;
  const ok = Boolean(expect(s));
  if (!ok) fails++;
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}: ${d ? `${d.ok ? "soft capture" : "HARD CONTACT"} at t=${d.t} s, ${(d.lateral_miss_m * 100).toFixed(1)} cm off axis, ` +
    `${(d.contact_speed_mps * 100).toFixed(1)} cm/s` : "no contact"}; ${s.vision_fixes} fixes, measurement error mean ` +
    `${(s.measurement_error_m.mean * 100).toFixed(1)} cm; dv ${s.delta_v_mps.toFixed(3)} m/s; events ${JSON.stringify(s.events.map((e) => e.slice(0, 2)))} ` +
    `(${((Date.now() - t0) / 1000).toFixed(0)} s)`);
}
console.log(fails ? `${fails} FAILED` : "ALL PASSED");
process.exit(fails ? 1 : 0);
