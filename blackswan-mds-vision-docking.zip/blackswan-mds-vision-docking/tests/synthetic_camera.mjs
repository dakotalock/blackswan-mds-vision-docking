// A small ray tracer for tests: the target's docking face as the camera sees it (space, the gold face, the marker's
// white quiet zone and its 7x7 cells), 3x3 supersampled with a little sensor noise. Grey levels, top row first.
import { MARKER_BITS } from "../web/src/aruco.js";
import { gauss, v3 } from "../web/src/linalg.js";

const grid = [[0, 0, 0, 0, 0, 0, 0], ...MARKER_BITS.map((r) => [0, ...r, 0]), [0, 0, 0, 0, 0, 0, 0]];

/** R, t: marker frame -> OpenCV camera frame. Returns a Float32Array of grey levels. */
export function renderMarker(K, W, H, side, R, t, rng, faceHalf = 2.2) {
  const cell = side / 7, h = side / 2;
  const shade = (a, b) => {
    if (Math.abs(a) < h && Math.abs(b) < h) { const j = Math.floor((a + h) / cell), i = Math.floor((h - b) / cell); return grid[i][j] ? 225 : 22; }
    if (Math.abs(a) < h + 0.5 * cell && Math.abs(b) < h + 0.5 * cell) return 215;
    if (Math.abs(a + 1.22) < faceHalf && Math.abs(b + 1.22) < faceHalf) return 110 + 25 * Math.sin(a * 9) * Math.cos(b * 7);
    return 8;
  };
  const g = new Float32Array(W * H), n = [R[0][2], R[1][2], R[2][2]];
  for (let v = 0; v < H; v++) for (let u = 0; u < W; u++) {
    let s = 0;
    for (let a = 0; a < 3; a++) for (let b = 0; b < 3; b++) {
      const d = [(u - K[0][2] + (b - 1) / 3) / K[0][0], (v - K[1][2] + (a - 1) / 3) / K[1][1], 1];
      const lam = v3.dot(n, t) / v3.dot(n, d);
      if (!(lam > 0)) { s += 8; continue; }
      const p = v3.sub(v3.scale(d, lam), t);
      s += shade(R[0][0] * p[0] + R[1][0] * p[1] + R[2][0] * p[2], R[0][1] * p[0] + R[1][1] * p[1] + R[2][1] * p[2]);
    }
    g[v * W + u] = s / 9 + gauss(rng) * 1.5;
  }
  return g;
}
