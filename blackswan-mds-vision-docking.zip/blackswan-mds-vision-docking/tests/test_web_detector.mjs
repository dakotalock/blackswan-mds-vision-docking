// The web version's ArUco detector on synthetic camera images with known corner positions.
// Each image is ray-traced (3x3 supersampled) from the marker's known pose: space, the docking face, the white
// quiet zone and the marker's cells. Run: node tests/test_web_detector.mjs
import { detectMarker } from "../web/src/aruco.js";
import { renderMarker } from "./synthetic_camera.mjs";
import { seeded, mulVec, rotvec, mul, v3 } from "../web/src/linalg.js";
import { CameraModel, project } from "../web/src/pose.js";

const cam = new CameraModel(), K = cam.K, W = 640, H = 480;
const side = 1.353;
const render = (R, t) => renderMarker(K, W, H, side, R, t, rng);
const rng = seeded(7);
let fails = 0, all = [];
for (let k = 0; k < 16; k++) {
  const d = 2.8 + (k / 15) * 14;                        // 2.8 .. 16.8 m
  // facing the camera (flipped about x), tilted up to +-15 deg, rolled to any angle about the line of sight
  const R = mul(rotvec([0, 0, 2 * Math.PI * rng()]), mul(rotvec([0, 0.5 * (rng() - 0.5), 0]), rotvec([Math.PI + 0.5 * (rng() - 0.5), 0, 0])));
  const t = [0.12 * d * (rng() - 0.5), 0.12 * d * (rng() - 0.5), d];
  const h = side / 2, truth = [[-h, h, 0], [h, h, 0], [h, -h, 0], [-h, -h, 0]].map((p) => project(K, v3.add(mulVec(R, p), t)));
  const det = detectMarker(render(R, t), W, H);
  if (!det) { console.log(`FAIL  ${d.toFixed(1)} m: marker not found`); fails++; continue; }
  const err = Math.max(...det.corners.map((c, i) => Math.hypot(c[0] - truth[i][0], c[1] - truth[i][1])));
  const px = Math.hypot(truth[0][0] - truth[1][0], truth[0][1] - truth[1][1]);
  all.push(err);
  const ok = err < 0.35;
  if (!ok) fails++;
  console.log(`${ok ? "PASS" : "FAIL"}  ${d.toFixed(1).padStart(4)} m, marker ${px.toFixed(0).padStart(3)} px wide: worst corner error ${err.toFixed(3)} px (window ${det.window})`);
}
console.log(`mean worst-corner error ${(all.reduce((a, b) => a + b, 0) / all.length).toFixed(3)} px`);
console.log(fails ? `${fails} FAILED` : "ALL PASSED");
process.exit(fails ? 1 : 0);
