// The web version's flight software against the Python reference numbers (tests/parity_fixtures.json).
// Run: node tests/test_web_parity.mjs   (Node 18+, no dependencies)
import { readFileSync } from "node:fs";
import { cwAccel, cwStm, Guidance, lvlhRotation, meanMotion, RelNavFilter, cwPropagate } from "../web/src/flight.js";
import { CameraModel, FiducialTarget, poseFromCorners } from "../web/src/pose.js";

const fx = JSON.parse(readFileSync(new URL("./parity_fixtures.json", import.meta.url)));
let failures = 0;
const maxDiff = (a, b) => {
  const fa = [a].flat(Infinity), fb = [b].flat(Infinity);
  if (fa.length !== fb.length) return Infinity;
  return Math.max(0, ...fa.map((x, i) => Math.abs(x - fb[i])));
};
function check(name, diff, tol) {
  const ok = diff <= tol;
  if (!ok) failures++;
  console.log(`${ok ? "PASS" : "FAIL"}  ${name.padEnd(58)} max difference ${diff.toExponential(2)} (tolerance ${tol.toExponential(0)})`);
}
const rel = (a, b) => maxDiff(a, b) / Math.max(1e-300, ...[b].flat(Infinity).map(Math.abs));

check("LVLH frame", maxDiff(lvlhRotation(fx.lvlh.r, fx.lvlh.v), fx.lvlh.R), 1e-15);
check("mean motion", Math.abs(meanMotion(fx.lvlh.r) - fx.lvlh.n) / fx.lvlh.n, 1e-15);
for (const c of fx.cw_stm) check(`Clohessy-Wiltshire transition matrix, dt=${c.dt} s`, rel(cwStm(fx.n, c.dt), c.F), 1e-12);
check("CW natural acceleration", maxDiff(fx.cw_accel.map((c) => cwAccel(c.x, fx.n)), fx.cw_accel.map((c) => c.a)), 1e-18);

// Kalman filter, step by step (including the gated outliers and the re-inflation)
{
  const f = fx.filter, nav = new RelNavFilter(fx.n, f.x0, f.pos_sigma, f.vel_sigma);
  let dx = 0, dP = 0, acceptOk = true;
  for (const s of f.steps) {
    nav.predict(s.dt, s.accel);
    if (s.z) acceptOk &&= nav.updatePosition(s.z, s.sigma) === s.accepted;
    dx = Math.max(dx, maxDiff(nav.x, s.x)); dP = Math.max(dP, rel(nav.P, s.P));
  }
  check("Kalman filter state over 30 steps", dx, 1e-12);
  check("Kalman filter covariance over 30 steps (relative)", dP, 1e-10);
  check("Kalman filter accept/reject decisions", acceptOk ? 0 : 1, 0);
}

// Guidance and the safety monitor
{
  const g = new Guidance();
  let da = 0, phases = true, events = true;
  for (const c of fx.guidance) {
    const a = g.command(c.t, c.x, c.axis, fx.n, c.since_fix, c.pos_sigma);
    da = Math.max(da, maxDiff(a, c.accel));
    phases &&= g.phase === c.phase;
    events &&= JSON.stringify(g.events) === JSON.stringify(c.events);
  }
  check("guidance acceleration commands", da, 1e-15);
  check("guidance phases (APPROACH / ABORT)", phases ? 0 : 1, 0);
  check("guidance event log, word for word", events ? 0 : 1, 0);
}

// Pose from corners: same two-solution choice, same numbers as OpenCV's IPPE + Levenberg-Marquardt
{
  const P = fx.pose;
  const cal = { cam_offset_body: P.cam_offset_body, marker_side_m: P.marker_side_m, marker_center_target: P.marker_center_target,
                R_target_marker: P.R_target_marker };
  const cam = new CameraModel(cal), target = new FiducialTarget(cal);
  cam.K = P.K; cam.R_body_cam = P.R_body_cam;
  // OpenCV's refinement stops a little short of the minimum at long range (its default stopping rule); this port
  // iterates to convergence. So: the same solution must be chosen, within 1 mm and 0.02 deg, and fit the corners at
  // least as well as OpenCV's answer does.
  for (const c of P.cases) {
    const p = poseFromCorners(c.corners, cam, target, c.prior_axis_cam, c.prior_R_ct);
    const same = p.source === c.source;
    const label = `pose at ${c.range} m (${c.source}${c.prior_axis_cam ? "" : ", no prior"})`;
    check(`${label}: position`, same ? maxDiff(p.tct, c.t_ct) : Infinity, 1e-3);
    check(`${label}: attitude`, maxDiff(p.Rct, c.R_ct), 3.5e-4);
    check(`${label}: fit no worse than OpenCV (px)`, Math.max(0, p.reprojPx - c.reproj_px), 1e-9);
  }
}

// A complete closed-loop docking run, with the same random draws
{
  const C = fx.closed_loop, nz = C.noise;
  let x = nz.x0.slice();
  const nav = new RelNavFilter(fx.n, nz.nav_x0, 2.0, 0.05), g = new Guidance();
  let t = 0, lastFix = -1e9, nextV = 0, dv = 0, k = 0, maxDev = 0, result = null;
  const axis = nz.axis;
  for (let step = 0; t < 300; step++) {
    if (t >= nextV) {
      nextV = t + 4.0;
      const rr = Math.hypot(x[0], x[1], x[2]);
      if (rr > 2.7) {
        const sigma = rr > 10 ? 0.01 + 0.0015 * rr ** 2 : 0.01 + 0.002 * rr;
        if (nav.updatePosition([0, 1, 2].map((i) => x[i] + sigma * nz.meas[k][i]), sigma)) lastFix = t;
        k++;
      }
    }
    const along = x[0] * axis[0] + x[1] * axis[1] + x[2] * axis[2];
    if (along < 0.05) {
      const lat = Math.hypot(...[0, 1, 2].map((i) => x[i] - along * axis[i]));
      result = { t, lateral_m: lat, speed_mps: Math.hypot(x[3], x[4], x[5]), dv, events: g.events };
      break;
    }
    const a = g.command(t, nav.x, axis, fx.n, t - lastFix, nav.posSigma);
    const aTrue = a.map((ai, i) => ai * 1.02 + 2e-5 * nz.thrust[Math.trunc(t)][i]);
    x = cwPropagate(fx.n, x, aTrue, 1.0);
    nav.predict(1.0, a); dv += Math.hypot(...a); t += 1.0;
    const ref = C.trace[step];
    maxDev = Math.max(maxDev, maxDiff(x, ref.x), maxDiff(nav.x, ref.nav_x));
  }
  const R = C.result;
  check(`closed-loop run: every step's truth and estimate (${C.trace.length} steps)`, maxDev, 1e-9);
  check(`closed-loop run: docked at the same second (t=${R.t} s)`, result ? Math.abs(result.t - R.t) : Infinity, 0);
  check(`closed-loop run: lateral miss (${(R.lateral_m * 100).toFixed(2)} cm) and contact speed`,
        result ? Math.max(Math.abs(result.lateral_m - R.lateral_m), Math.abs(result.speed_mps - R.speed_mps)) : Infinity, 1e-9);
  check("closed-loop run: event log", result && JSON.stringify(result.events) === JSON.stringify(R.events) ? 0 : 1, 0);
}

console.log(failures ? `\n${failures} FAILED` : "\nALL PASSED: the web flight software reproduces the Python numbers");
process.exit(failures ? 1 : 0);
