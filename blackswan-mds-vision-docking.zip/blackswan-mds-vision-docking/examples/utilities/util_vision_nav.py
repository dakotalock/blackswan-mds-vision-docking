"""Vision-based relative navigation for MDS rendezvous & docking.

The chaser never reads the target's state from the simulator. It sees the target only through its own sensors:
  - the MDS camera (RGB): the ArUco fiducial on the target's docking face gives a full 6-DoF pose (IPPE PnP);
  - optionally the MDS depth camera (a flash-lidar stand-in), used only as a gated cross-check of the camera's range.
The chaser does know its OWN state (GNSS + star tracker in a real spacecraft): position, velocity and attitude from
get_sat_data() for the chaser only. The target's state from the simulator is used for scoring only, never for control.

Frames used here
  - chaser body (MDS): +X is the camera boresight and the docking-port axis.
  - camera (OpenCV): x right, y down, z forward. Calibrated against MDS: x_c = -Z_b, y_c = +Y_b, z_c = +X_b.
  - LVLH of the target (Hill): x radial (away from Earth), y along-track, z orbit normal. Guidance runs here.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field

import cv2
import numpy as np
from scipy.spatial.transform import Rotation as Rot

# ---------------------------------------------------------------------------------------------------------------
# Sensor models
# ---------------------------------------------------------------------------------------------------------------

@dataclass
class CameraModel:
    """Pinhole model of the MDS camera, as attached with attach_camera_to_sat()."""
    width: int = 640
    height: int = 480
    focal_length_mm: float = 20.7
    sensor_width_mm: float = 36.0          # gate fit "Horizontal": horizontal FOV from the sensor width
    offset_body: np.ndarray = field(default_factory=lambda: np.zeros(3))   # camera position in the chaser body frame [m]
    # camera axes in the chaser body frame (calibrated against MDS): x_c = -Z_b, y_c = +Y_b, z_c = +X_b (boresight)
    R_body_cam: np.ndarray = field(default_factory=lambda: np.column_stack([[0, 0, -1], [0, 1, 0], [1, 0, 0]]).astype(float))

    focal_scale: float = 1.0               # calibrated correction to the nominal focal length

    @classmethod
    def from_calibration(cls, cal: dict) -> "CameraModel":
        c = cls(offset_body=np.array(cal["cam_offset_body"]), focal_scale=cal.get("focal_scale", 1.0))
        if "camera_mount_rotvec" in cal:
            c.R_body_cam = Rot.from_rotvec(cal["camera_mount_rotvec"]).as_matrix() @ c.R_body_cam
        return c

    @property
    def K(self) -> np.ndarray:
        f = self.focal_length_mm / self.sensor_width_mm * self.width * self.focal_scale
        return np.array([[f, 0, (self.width - 1) / 2], [0, f, (self.height - 1) / 2], [0, 0, 1]])

    def ray(self, u: float, v: float) -> np.ndarray:
        """Unit ray (camera frame) through pixel (u, v)."""
        K = self.K
        d = np.array([(u - K[0, 2]) / K[0, 0], (v - K[1, 2]) / K[1, 1], 1.0])
        return d / np.linalg.norm(d)


def decode_rgb(frame_bytes: bytes) -> np.ndarray:
    return cv2.imdecode(np.frombuffer(frame_bytes, np.uint8), cv2.IMREAD_COLOR)


def decode_depth(frame_bytes: bytes, cam: CameraModel) -> np.ndarray:
    """MDS depth frame -> metres (z-depth along the boresight), same pixel layout as the RGB frame.
    Pixels with no return (space, or beyond the depth camera's ~20 m range) are NaN."""
    d = np.frombuffer(frame_bytes, np.float32).reshape(cam.height, cam.width).astype(float)
    d[d <= 0] = np.nan
    return d


# ---------------------------------------------------------------------------------------------------------------
# Target model: the ArUco fiducial on the docking face
# ---------------------------------------------------------------------------------------------------------------

@dataclass
class FiducialTarget:
    """Where the fiducial sits on the target, in the target body frame (calibrated once, like a CAD model)."""
    marker_id: int = 3
    side_m: float = 1.0
    center_target: np.ndarray = field(default_factory=lambda: np.zeros(3))
    R_target_marker: np.ndarray = field(default_factory=lambda: np.eye(3))
    port_target: np.ndarray = field(default_factory=lambda: np.array([0.0, 0.0, 3.18]))   # docking port [m]
    port_axis_target: np.ndarray = field(default_factory=lambda: np.array([0.0, 0.0, 1.0]))
    dictionary: int = cv2.aruco.DICT_5X5_50

    @classmethod
    def from_json(cls, path: str) -> "FiducialTarget":
        c = json.load(open(path))
        return cls(side_m=c["marker_side_m"], center_target=np.array(c["marker_center_target"]),
                   R_target_marker=np.array(c["R_target_marker"]))

    def __post_init__(self):
        self._detector = cv2.aruco.ArucoDetector(cv2.aruco.getPredefinedDictionary(self.dictionary), cv2.aruco.DetectorParameters())

    def detect(self, rgb: np.ndarray):
        """Corners (4x2, ArUco order) of this target's marker, or None."""
        gray = cv2.cvtColor(rgb, cv2.COLOR_BGR2GRAY)
        corners, ids, _ = self._detector.detectMarkers(gray)
        if ids is None or self.marker_id not in ids.ravel():
            return None
        c = corners[list(ids.ravel()).index(self.marker_id)].reshape(4, 2)
        cv2.cornerSubPix(gray, c, (5, 5), (-1, -1), (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 40, 0.01))
        return c

    def object_points(self) -> np.ndarray:
        h = self.side_m / 2
        return np.array([[-h, h, 0], [h, h, 0], [h, -h, 0], [-h, -h, 0]], float)


@dataclass
class PoseMeasurement:
    """Target pose in the camera frame: p_cam = R_ct @ p_target + t_ct."""
    R_ct: np.ndarray
    t_ct: np.ndarray
    reproj_px: float
    source: str                      # "marker", "marker+depth"
    marker_px: float                 # marker size in the image (pixels), a quality indicator


def estimate_pose(rgb: np.ndarray, depth: np.ndarray | None, cam: CameraModel, target: FiducialTarget,
                  prior_axis_cam: np.ndarray | None = None, prior_R_ct: np.ndarray | None = None,
                  min_attitude_px: float = 35.0) -> PoseMeasurement | None:
    """6-DoF target pose from one RGB frame.

    A small planar marker seen from afar has two nearly equally good poses (the IPPE ambiguity: mirror-image tilts).
    Both are computed; the one whose docking axis agrees with the navigation prior (prior_axis_cam, the predicted
    docking axis in the camera frame) is kept, or the lower-reprojection one when there is no prior.
    When the marker spans fewer than min_attitude_px pixels its tilt is too uncertain to use (a 1 px corner error is
    many degrees), so only its position is taken from the image and the target's attitude comes from the prior
    (prior_R_ct, the navigation filter's estimate): "position-only" mode.
    The depth frame is used only as a gated cross-check of the range: MDS depth frames can lag the RGB frame, so a
    depth value is accepted only when it agrees with the camera within 5 %."""
    c = target.detect(rgb)
    if c is None:
        return None
    pose = pose_from_corners(c, cam, target, prior_axis_cam, prior_R_ct, min_attitude_px)
    if pose is not None and depth is not None:
        mask = np.zeros(depth.shape, np.uint8)
        cv2.fillConvexPoly(mask, c.astype(np.int32), 1)
        z = depth[mask.astype(bool)]
        z = z[np.isfinite(z)]
        z_cam = (pose.R_ct @ target.center_target + pose.t_ct)[2]
        if z.size > 30 and abs(np.median(z) - z_cam) < 0.05 * z_cam:
            pose.source += " + depth"            # independent range confirmation
    return pose


def pose_from_corners(c: np.ndarray, cam: CameraModel, target: FiducialTarget, prior_axis_cam: np.ndarray | None = None,
                      prior_R_ct: np.ndarray | None = None, min_attitude_px: float = 35.0) -> PoseMeasurement | None:
    """The geometry half of estimate_pose(): target pose from the marker's four corner pixels (ArUco order)."""
    c = np.asarray(c, np.float64).reshape(4, 2)
    n, rvs, tvs, errs = cv2.solvePnPGeneric(target.object_points(), c, cam.K, None, flags=cv2.SOLVEPNP_IPPE_SQUARE)
    if n == 0:
        return None
    R_tm, c_tm = target.R_target_marker, target.center_target
    cands = []
    for rv, tv in zip(rvs, tvs):
        rv, tv = cv2.solvePnPRefineLM(target.object_points(), c, cam.K, None, rv, tv)
        proj, _ = cv2.projectPoints(target.object_points(), rv, tv, cam.K, None)
        reproj = float(np.sqrt(np.mean(np.sum((proj.reshape(4, 2) - c) ** 2, axis=1))))
        R_ct = Rot.from_rotvec(rv.ravel()).as_matrix() @ R_tm.T
        t_ct = tv.ravel() - R_ct @ c_tm
        axis = R_ct @ target.port_axis_target
        agree = float(axis @ prior_axis_cam) if prior_axis_cam is not None else 0.0
        cands.append((R_ct, t_ct, reproj, agree))
    if prior_axis_cam is not None:
        R_ct, t_ct, reproj, _ = max(cands, key=lambda k: k[3] - 0.02 * k[2])
    else:
        R_ct, t_ct, reproj, _ = min(cands, key=lambda k: k[2])
    source = "marker"
    size = float(np.mean(np.linalg.norm(c - np.roll(c, 1, axis=0), axis=1)))
    if size < min_attitude_px and prior_R_ct is not None:
        marker_c = R_ct @ c_tm + t_ct                    # marker centre (well determined even when tiny)
        R_ct = prior_R_ct
        t_ct = marker_c - R_ct @ c_tm
        source = "marker (position only)"
    return PoseMeasurement(R_ct, t_ct, reproj, source, size)


# ---------------------------------------------------------------------------------------------------------------
# Frames
# ---------------------------------------------------------------------------------------------------------------

def lvlh_rotation(r: np.ndarray, v: np.ndarray) -> np.ndarray:
    """Rows are the LVLH axes (x radial, y along-track, z orbit normal) in the inertial frame: p_lvlh = R @ p_inertial."""
    x = r / np.linalg.norm(r)
    z = np.cross(r, v); z /= np.linalg.norm(z)
    y = np.cross(z, x)
    return np.vstack([x, y, z])


def mean_motion(r: np.ndarray, mu: float = 3.986004418e14) -> float:
    return float(np.sqrt(mu / np.linalg.norm(r) ** 3))


# ---------------------------------------------------------------------------------------------------------------
# Relative navigation filter (Clohessy-Wiltshire Kalman filter)
# ---------------------------------------------------------------------------------------------------------------

def cw_stm(n: float, t: float) -> np.ndarray:
    s, c, nt = np.sin(n * t), np.cos(n * t), n * t
    return np.array([
        [4 - 3 * c, 0, 0, s / n, 2 * (1 - c) / n, 0],
        [6 * (s - nt), 1, 0, 2 * (c - 1) / n, (4 * s - 3 * nt) / n, 0],
        [0, 0, c, 0, 0, s / n],
        [3 * n * s, 0, 0, c, 2 * s, 0],
        [6 * n * (c - 1), 0, 0, -2 * s, 4 * c - 3, 0],
        [0, 0, -n * s, 0, 0, c],
    ])


class RelNavFilter:
    """State: chaser docking port relative to the target docking port, in the target's LVLH frame [m, m/s]."""

    def __init__(self, n: float, x0: np.ndarray, pos_sigma: float, vel_sigma: float, accel_noise: float = 2e-4):
        self.n, self.x = n, np.asarray(x0, float).copy()
        self.P = np.diag([pos_sigma ** 2] * 3 + [vel_sigma ** 2] * 3)
        self.q = accel_noise ** 2

    def predict(self, dt: float, accel: np.ndarray):
        F = cw_stm(self.n, dt)
        B = np.vstack([0.5 * dt * dt * np.eye(3), dt * np.eye(3)])
        self.x = F @ self.x + B @ accel
        Q = np.zeros((6, 6)); q = self.q
        Q[:3, :3] = q * dt ** 3 / 3 * np.eye(3); Q[:3, 3:] = Q[3:, :3] = q * dt ** 2 / 2 * np.eye(3); Q[3:, 3:] = q * dt * np.eye(3)
        self.P = F @ self.P @ F.T + Q

    def update_position(self, z: np.ndarray, sigma: float, gate: float = 5.0) -> bool:
        """Kalman update with innovation gating. Three rejections in a row mean the filter, not the sensor, is wrong
        (an unmodelled push, say): the position covariance is re-inflated so the measurement can pull it back."""
        H = np.hstack([np.eye(3), np.zeros((3, 3))])
        S = H @ self.P @ H.T + sigma ** 2 * np.eye(3)
        y = z - H @ self.x
        if y @ np.linalg.solve(S, y) > gate ** 2 * 3:
            self.rejections = getattr(self, "rejections", 0) + 1
            if self.rejections < 3:
                return False
            self.P[:3, :3] += np.diag(y ** 2 + sigma ** 2); self.P[3:, 3:] += np.eye(3) * 0.02 ** 2
            S = H @ self.P @ H.T + sigma ** 2 * np.eye(3)
        self.rejections = 0
        K = self.P @ H.T @ np.linalg.inv(S)
        self.x = self.x + K @ y
        self.P = (np.eye(6) - K @ H) @ self.P
        self.P = 0.5 * (self.P + self.P.T)
        return True

    @property
    def pos_sigma(self) -> float:
        return float(np.sqrt(np.trace(self.P[:3, :3])))


def cw_accel(x: np.ndarray, n: float) -> np.ndarray:
    """Natural relative acceleration (gravity gradient + Coriolis) the controller cancels."""
    return np.array([3 * n * n * x[0] + 2 * n * x[4], -2 * n * x[3], -n * n * x[2]])


# ---------------------------------------------------------------------------------------------------------------
# Guidance with a safety monitor
# ---------------------------------------------------------------------------------------------------------------

@dataclass
class Guidance:
    """Straight-line approach along the target's docking axis, slowing as it closes, with automatic aborts."""
    corridor_deg: float = 10.0
    keep_out_m: float = 15.0
    final_speed: float = 0.03        # m/s at contact
    max_speed: float = 0.20
    max_accel: float = 0.01          # m/s^2
    retreat_to_m: float = 12.0
    lost_lock_s: float = 12.0
    commit_range_m: float = 3.0      # committed final approach: inside this range, with a converged filter,
    commit_sigma_m: float = 0.05     # losing sight of the marker (it leaves the field of view) is expected;
    commit_coast_s: float = 90.0     # the chaser finishes on inertial navigation for up to this long
    phase: str = "APPROACH"
    events: list = field(default_factory=list)

    def command(self, t: float, x: np.ndarray, axis_lvlh: np.ndarray, n: float, since_fix: float,
                pos_sigma: float = 1.0) -> np.ndarray:
        """Acceleration command in LVLH. x: chaser port relative to target port (LVLH), axis_lvlh: the target's
        docking axis (pointing out of the port, toward the chaser's side)."""
        r, v = x[:3], x[3:]
        along = float(r @ axis_lvlh)
        lateral = r - along * axis_lvlh
        off_axis = np.degrees(np.arctan2(np.linalg.norm(lateral), max(along, 1e-6)))
        rng = np.linalg.norm(r)
        if self.phase == "APPROACH":
            if rng < self.keep_out_m and off_axis > self.corridor_deg and rng > 1.0:
                self._event(t, "ABORT", f"outside the approach corridor ({off_axis:.1f} deg)")
            elif since_fix > self.lost_lock_s and rng < self.keep_out_m:
                committed = rng < self.commit_range_m and pos_sigma < self.commit_sigma_m + 0.002 * since_fix
                if not committed:
                    self._event(t, "ABORT", f"no navigation fix for {since_fix:.0f} s")
                elif since_fix > self.commit_coast_s:
                    self._event(t, "ABORT", f"final approach coasted {since_fix:.0f} s without a fix")
                elif not getattr(self, "_committed", False):
                    self._committed = True
                    self.events.append((round(t, 1), "COMMITTED", f"marker out of view at {rng:.1f} m; finishing on inertial navigation"))
        if self.phase == "ABORT" and along > self.retreat_to_m and since_fix < 3:
            self._event(t, "APPROACH", "safe hold reached and target re-acquired: approaching again")
        if self.phase == "APPROACH":
            speed = np.clip(0.02 * along + self.final_speed, self.final_speed, self.max_speed)
            v_cmd = -speed * axis_lvlh - 0.05 * lateral
        else:  # ABORT: back away along the axis
            v_cmd = 0.1 * axis_lvlh - 0.03 * lateral
        a = 0.2 * (v_cmd - v) - cw_accel(x, n)
        na = np.linalg.norm(a)
        return a if na <= self.max_accel else a * self.max_accel / na

    def _event(self, t, phase, why):
        self.phase = phase
        self.events.append((round(t, 1), phase, why))
