"""
Vision-in-the-loop autonomous docking in MDS.

MDS's own docking demo (demo_gnc_docking.py) steers with the simulator's true states. Here the chaser steers only by
what it senses of the target:
  - the MDS camera sees the ArUco fiducial on the target's docking face -> 6-DoF pose (PnP),
  - optionally (--depth) the MDS depth camera cross-checks the camera's range,
  - a Clohessy-Wiltshire Kalman filter fuses them and carries the estimate between frames,
  - guidance flies the docking axis with a safety monitor (approach corridor, loss of navigation) that aborts,
    backs away and retries on its own.
The chaser knows its OWN position, velocity and attitude (GNSS + star tracker). The target's true state is read
from MDS only to score the navigation, never to steer.

Outputs (in examples/outputs/vision_docking_<time>/): telemetry.csv, an annotated camera video, summary.json.
Run MDS first, then:  python examples/demo_vision_docking.py [--start-range 10] [--vision-period 4] [--seed 2]
"""
import argparse
import csv
import json
import os
import sys
import time

import cv2
import numpy as np
from scipy.spatial.transform import Rotation as Rot

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from mds_api import mds_api  # noqa: E402
import utilities.util_attitude as att  # noqa: E402
from utilities.util_vision_nav import (CameraModel, FiducialTarget, Guidance, RelNavFilter, decode_depth,  # noqa: E402
                                       decode_rgb, estimate_pose, lvlh_rotation, mean_motion)

HERE = os.path.dirname(os.path.abspath(__file__))
vec = lambda s: np.fromstring(s.strip("()"), sep=", ")  # noqa: E731


def own_state(name):
    """Chaser's own navigation (GNSS + star tracker): position, velocity, attitude."""
    _, d = mds_api.get_sat_data(name)
    return vec(d["localPosition"]), vec(d["localVelocity"]), Rot.from_quat(vec(d["attitudeState"]["attitude"]))


def truth_state(name):
    """Target truth, for scoring only."""
    _, d = mds_api.get_sat_data(name)
    return vec(d["localPosition"]), vec(d["localVelocity"]), Rot.from_quat(vec(d["attitudeState"]["attitude"]))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--start-range", type=float, default=14.0, help="initial port-to-port distance [m]")
    ap.add_argument("--vision-period", type=float, default=3.0, help="seconds of mission time between camera frames")
    ap.add_argument("--final-vision-period", type=float, default=10.0, help="camera period once the marker is out of view [s]")
    ap.add_argument("--dt", type=float, default=1.0, help="control period / MDS propagation step [s]")
    ap.add_argument("--max-time", type=float, default=560.0, help="mission time limit [s] (the MDS trial allows 600 s)")
    ap.add_argument("--calibration", default=os.path.join(HERE, "data", "vision_docking_calibration.json"))
    ap.add_argument("--dropout", type=float, nargs=2, metavar=("T0", "T1"), help="inject a camera dropout between T0 and T1 s")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--physics", choices=["cw", "mds"], default="cw",
                    help="cw: relative motion propagated here, MDS renders every camera frame (software-in-the-loop);"
                         " mds: MDS propagates and the chaser is flown with apply_thrust_torque (needs a real-time machine)")
    ap.add_argument("--depth", action="store_true", help="also read MDS depth frames as a range cross-check")
    args = ap.parse_args()
    rng = np.random.default_rng(args.seed)

    out_dir = os.path.join(HERE, "outputs", time.strftime("vision_docking_%Y%m%d_%H%M%S"))
    os.makedirs(out_dir, exist_ok=True)
    cal = json.load(open(args.calibration))
    cam = CameraModel.from_calibration(cal)
    target_model = FiducialTarget.from_json(args.calibration)
    port_chaser = np.array([2.12, 0.0, 0.0])          # chaser docking port, body frame (DockChaser_BSS model)

    # ---------------- scene: same orbit and models as MDS's demo_gnc_docking.py ----------------
    name_t, name_c = "target", "chaser"
    a, e, inc, w, raan, ta_t = 7630e3, 0.0001, 100.7, 0.0, 120.0, 90.0
    m_chaser, m_target = 2000.0, 4400.0
    from utilities import util_orbits as orb
    mu = 3.96e14
    n0 = np.sqrt(mu / a ** 3)
    r_k, v_k = orb.kepler_to_cartesian(a, e, np.deg2rad(inc), np.deg2rad(raan), np.deg2rad(w), np.deg2rad(ta_t), mu)
    rot_lvlh_t = Rot.from_matrix(att.get_rot_lvlh(r_k, v_k))
    att_target = rot_lvlh_t.inv() * Rot.from_euler("xyz", [3.14, 3.14 / 2, 0])     # docking port faces -V (as in MDS demo)

    mds_api.clear_scene()
    mds_api.enable_API_synchronization()
    mds_api.set_simulation_timestep(args.dt)
    mds_api.set_utc_date(2026, 6, 13, 11, 59, 59, 0)
    mds_api.set_time_scale(0)
    mds_api.add_sat_from_elements(name_t, m_target, a, e, inc, raan, w, ta_t, "Earth", attitude=att_target.as_quat(),
                                  custom_model_path="/CustomModels/GEOSAT/GEOSAT_original_real-size_docking.glb",
                                  rigidbody=True, angular_velocity=rot_lvlh_t.apply([0, n0, 0]))
    mds_api.add_sat_from_elements(name_c, m_chaser, a, e, inc, raan, w, ta_t - 0.01, "Earth", rigidbody=True,
                                  custom_model_path="/CustomModels/chaser/DockChaser_BSS.glb")
    time.sleep(0.3)
    # Scenario set-up (not navigation): place the chaser start_range out along the target's docking axis,
    # with a small lateral offset and pointing error
    r_t0, v_t0, R_t0 = truth_state(name_t)
    port_t0 = r_t0 + R_t0.apply(target_model.port_target)
    axis_t0 = R_t0.apply(target_model.port_axis_target)
    lateral = rng.normal(0, 0.06 * args.start_range, 3); lateral -= axis_t0 * (lateral @ axis_t0)
    r_c0 = port_t0 + axis_t0 * (args.start_range + port_chaser[0]) + lateral
    # roll reference: the orbit normal (never parallel to a V-bar approach, unlike the velocity vector)
    q_c0 = att.get_rot_x_aligned(port_t0 - r_c0, np.cross(r_t0, v_t0)) * Rot.from_euler("zyx", rng.normal(0, 1.5, 3), degrees=True)
    mds_api.set_sat_position(name_c, list(r_c0)); mds_api.set_sat_velocity(name_c, list(v_t0))
    mds_api.set_sat_attitude(name_c, list(q_c0.as_quat()))
    time.sleep(0.3)
    mds_api.attach_camera_to_sat(name_c, focal_length=cam.focal_length_mm, near_plane=0.2, far_plane=1e8,
                                 distance_from_satellite=-1.91, texture_width=cam.width, texture_height=cam.height)
    mds_api.select_satellite(name_c)

    # ---------------- the "plant": who moves the spacecraft ----------------
    r_t0, v_t0, R_t0 = truth_state(name_t)
    if args.physics == "mds":
        plant = MdsPhysicsPlant(name_c, name_t, port_chaser, target_model, m_chaser, args.dt)
    else:
        plant = CwPlant(name_c, r_t0, v_t0, R_t0, port_chaser, target_model, r_c0, q_c0, rng)

    # ---------------- navigation initialisation: a coarse hand-over estimate (e.g. from far-range nav) ----------------
    r_c, v_c, R_c = plant.own_state()
    R_lvlh = lvlh_rotation(r_c, v_c)
    n = mean_motion(r_c)
    x_true, axis_true = plant.truth(R_lvlh)
    nav = RelNavFilter(n, np.concatenate([x_true[:3] + rng.normal(0, 1.0, 3), np.zeros(3)]), pos_sigma=2.0, vel_sigma=0.05)
    axis_est = axis_true + rng.normal(0, 0.03, 3); axis_est /= np.linalg.norm(axis_est)
    R_ct_prior = None
    guidance = Guidance()

    video = cv2.VideoWriter(os.path.join(out_dir, "camera.mp4"), cv2.VideoWriter_fourcc(*"mp4v"), 4, (cam.width, cam.height))
    log = open(os.path.join(out_dir, "telemetry.csv"), "w", newline="")
    wr = csv.writer(log)
    wr.writerow(["t", "phase", "range_true", "rx_est", "ry_est", "rz_est", "rx_true", "ry_true", "rz_true", "vx_true", "vy_true", "vz_true",
                 "nav_err_m", "nav_sigma_m", "meas_err_m", "axis_err_deg", "fix", "dv_mps"])
    t, t_last_fix, t_next_vision, dv, docked = 0.0, -1e9, 0.0, 0.0, None
    fix_errors, frames, att_mismatch = [], 0, []
    t_wall = time.time()
    try:
        while t < args.max_time:
            r_c, v_c, R_c = plant.own_state()
            R_lvlh = lvlh_rotation(r_c, v_c)
            x_true, axis_true = plant.truth(R_lvlh)
            fix, meas_err = "", np.nan
            # ---------- sensing: an MDS-rendered camera frame ----------
            if t >= t_next_vision:
                # once the marker has left the view at close range, frames are only kept for the video record
                close_blind = np.linalg.norm(nav.x[:3]) < 3.0 and t - t_last_fix > args.vision_period + 0.5
                t_next_vision = t + (args.final_vision_period if close_blind else args.vision_period)
                dropout = bool(args.dropout) and args.dropout[0] <= t < args.dropout[1]
                rgb, depth = plant.render(with_depth=args.depth)
                frames += 1
                R_c = getattr(plant, "R_c_rendered", R_c)          # attitude at the moment of exposure
                att_mismatch.append(getattr(plant, "attitude_mismatch_deg", 0.0))
                prior_axis_cam = cam.R_body_cam.T @ R_c.inv().apply(R_lvlh.T @ axis_est)
                pose = None if dropout else estimate_pose(rgb, depth, cam, target_model, prior_axis_cam=prior_axis_cam, prior_R_ct=R_ct_prior)
                if pose is not None:
                    port_t_cam = pose.R_ct @ target_model.port_target + pose.t_ct
                    port_c_w = r_c + R_c.apply(port_chaser)
                    port_t_w = r_c + R_c.apply(cam.offset_body + cam.R_body_cam @ port_t_cam)
                    axis_w = R_c.apply(cam.R_body_cam @ pose.R_ct @ target_model.port_axis_target)
                    z = R_lvlh @ (port_c_w - port_t_w)
                    rng_m = float(np.linalg.norm(z))
                    sigma = 0.01 + 0.002 * rng_m if rng_m < 10 else 0.01 + 0.0015 * rng_m ** 2   # measured on MDS frames
                    if nav.update_position(z, sigma):
                        t_last_fix, fix = t, pose.source
                        if "position only" not in pose.source:
                            axis_est = 0.6 * axis_est + 0.4 * (R_lvlh @ axis_w); axis_est /= np.linalg.norm(axis_est)
                            R_ct_prior = pose.R_ct
                    meas_err = float(np.linalg.norm(z - x_true[:3]))
                    fix_errors.append((t, rng_m, meas_err, pose.source))
                video.write(annotate(rgb, pose, cam, target_model, t, guidance.phase, nav, dropout))
            # ---------- scoring ----------
            nav_err = float(np.linalg.norm(nav.x[:3] - x_true[:3]))
            axis_err = float(np.degrees(np.arccos(np.clip(axis_est @ axis_true, -1, 1))))
            wr.writerow([round(t, 1), guidance.phase, round(float(np.linalg.norm(x_true[:3])), 4), *np.round(nav.x[:3], 4),
                         *np.round(x_true, 4), round(nav_err, 4), round(nav.pos_sigma, 4), meas_err, round(axis_err, 3), fix, round(dv, 4)])
            # ---------- contact ----------
            along_true = float(x_true[:3] @ axis_true)
            if along_true < 0.0:
                lat = float(np.linalg.norm(x_true[:3] - along_true * axis_true)); spd = float(np.linalg.norm(x_true[3:]))
                ok = lat < 0.10 and spd < 0.06
                docked = dict(t=t, ok=ok, lateral_miss_m=lat, contact_speed_mps=spd)
                print(f"\n{'SOFT CAPTURE' if ok else 'HARD CONTACT'} at t={t:.0f} s: {lat*100:.1f} cm off the port axis, {spd*100:.1f} cm/s")
                if ok:
                    plant.dock()
                break
            # ---------- guidance & actuation ----------
            since_fix = t - t_last_fix
            accel = guidance.command(t, nav.x, axis_est, n, since_fix, nav.pos_sigma)
            # +X (camera, docking port) toward the target; roll referenced to the orbit normal
            q_cmd = att.get_rot_x_aligned(-(R_lvlh.T @ axis_est), R_lvlh.T @ np.array([0.0, 0.0, 1.0]))
            plant.actuate(accel, q_cmd, R_lvlh, args.dt)
            nav.predict(args.dt, accel)
            dv += float(np.linalg.norm(accel)) * args.dt
            t += args.dt
            sys.stdout.write(f"\rt={t:5.0f}s {guidance.phase:8s} range {np.linalg.norm(x_true[:3]):6.2f} m  nav err {nav_err*100:5.1f} cm"
                             f"  axis err {axis_err:4.1f} deg  dv {dv:5.3f} m/s  frames {frames}  wall {time.time()-t_wall:4.0f}s ")
            sys.stdout.flush()
    finally:
        video.release(); log.close()
        mds_api.disable_API_synchronization()
    errs = np.array([f[2] for f in fix_errors]) if fix_errors else np.array([np.nan])
    summary = dict(physics=args.physics, docked=docked, mission_time_s=t, delta_v_mps=dv, events=guidance.events,
                   mds_frames=frames, vision_fixes=len(fix_errors), wall_clock_s=round(time.time() - t_wall, 1),
                   render_attitude_mismatch_deg=dict(max=float(max(att_mismatch, default=0)), mean=float(np.mean(att_mismatch)) if att_mismatch else 0.0),
                   measurement_error_m=dict(mean=float(np.nanmean(errs)), p95=float(np.nanpercentile(errs, 95)), max=float(np.nanmax(errs))),
                   outputs=out_dir)
    json.dump(summary, open(os.path.join(out_dir, "summary.json"), "w"), indent=1)
    print("\n" + json.dumps(summary, indent=1))


class MdsPhysicsPlant:
    """MDS propagates both spacecraft; the chaser is flown with apply_thrust_torque and MDS's attitude control
    (pointing mode "CustomQuaternion"). Real time on a GPU workstation."""

    def __init__(self, name_c, name_t, port_chaser, target, mass, dt):
        self.c, self.t, self.port_c, self.target, self.m, self.dt = name_c, name_t, port_chaser, target, mass, dt
        mds_api.set_pointing_mode(name_c, "CustomQuaternion")

    def own_state(self):
        return own_state(self.c)

    def truth(self, R_lvlh):
        r_c, v_c, R_c = own_state(self.c); r_t, v_t, R_t = truth_state(self.t)
        rel = R_lvlh @ ((r_c + R_c.apply(self.port_c)) - (r_t + R_t.apply(self.target.port_target)))
        return np.concatenate([rel, R_lvlh @ (v_c - v_t)]), R_lvlh @ R_t.apply(self.target.port_axis_target)

    def render(self, with_depth=False):
        rgb = decode_rgb(mds_api.get_camera_frame(self.c))
        depth = decode_depth(mds_api.get_camera_depth_frame(self.c), CameraModel()) if with_depth else None
        return rgb, depth

    def actuate(self, accel, q_cmd, R_lvlh, dt):
        _, _, R_c = own_state(self.c)
        mds_api.apply_thrust_torque(self.c, list(R_c.inv().apply(R_lvlh.T @ (accel * self.m))), [0.0, 0.0, 0.0])
        mds_api.set_pointing_target(self.c, list(q_cmd.as_quat()))
        mds_api.step_sim(1, True)

    def dock(self):
        mds_api.attach_bodies(self.t, self.c)


class CwPlant:
    """MDS as the camera simulator (software-in-the-loop): relative motion is propagated here with the Clohessy-
    Wiltshire equations (thrust scale error and noise included), and every camera frame is rendered by MDS with the
    chaser placed at its true pose. MDS time stays frozen, so this runs within the trial's limits on any machine."""

    def __init__(self, name_c, r_t, v_t, R_t, port_chaser, target, r_c0, q_c0, rng):
        self.c, self.port_c, self.target, self.rng = name_c, port_chaser, target, rng
        self.r_t, self.v_t = r_t, v_t
        self.port_t_w = r_t + R_t.apply(target.port_target)
        self.R_L = lvlh_rotation(r_t, v_t)
        self.axis_L = self.R_L @ R_t.apply(target.port_axis_target)
        self.n = mean_motion(r_t)
        self.R_c = q_c0
        self.x = np.concatenate([self.R_L @ ((r_c0 + q_c0.apply(port_chaser)) - self.port_t_w), np.zeros(3)])

    def own_state(self):
        r_c = self.port_t_w + self.R_L.T @ self.x[:3] - self.R_c.apply(self.port_c)
        return r_c, self.v_t + self.R_L.T @ self.x[3:], self.R_c

    def truth(self, R_lvlh):
        return self.x.copy(), self.axis_L.copy()

    def render(self, with_depth=False):
        r_c, v_c, R_c = self.own_state()
        q = list(R_c.as_quat())
        mds_api.set_sat_position(self.c, list(r_c)); mds_api.set_sat_velocity(self.c, list(v_c))
        # hold the attitude exactly: MDS's attitude control would otherwise re-point the chaser (as in util_cv)
        mds_api.set_pointing_mode(self.c, "CustomQuaternion"); mds_api.set_pointing_target(self.c, q)
        mds_api.set_sat_attitude(self.c, q)
        time.sleep(0.4)
        # the chaser's star tracker: read back the attitude MDS actually rendered with
        _, d = mds_api.get_sat_data(self.c)
        self.R_c_rendered = Rot.from_quat(vec(d["attitudeState"]["attitude"]))
        self.attitude_mismatch_deg = float(np.degrees((self.R_c_rendered.inv() * R_c).magnitude()))
        rgb = decode_rgb(mds_api.get_camera_frame(self.c, delay=True))
        depth = decode_depth(mds_api.get_camera_depth_frame(self.c), CameraModel()) if with_depth else None
        return rgb, depth

    def actuate(self, accel, q_cmd, R_lvlh, dt):
        from utilities.util_vision_nav import cw_stm
        a_true = accel * 1.02 + self.rng.normal(0, 2e-5, 3)
        B = np.vstack([0.5 * dt * dt * np.eye(3), dt * np.eye(3)])
        self.x = cw_stm(self.n, dt) @ self.x + B @ a_true
        # attitude control: the commanded attitude, with 0.1 deg of pointing jitter
        self.R_c = Rot.from_rotvec(np.radians(0.1) * self.rng.normal(size=3)) * q_cmd

    def dock(self):
        pass


def annotate(rgb, pose, cam, target, t, phase, nav, dropout):
    img = rgb.copy()
    if dropout:
        img[:] = (img * 0.3).astype(np.uint8)
    if pose is not None:
        rv = cv2.Rodrigues(pose.R_ct)[0]
        cv2.drawFrameAxes(img, cam.K, None, rv, pose.t_ct.reshape(3, 1), 1.0, 2)
        port_px, _ = cv2.projectPoints(target.port_target.reshape(1, 3), rv, pose.t_ct, cam.K, None)
        cv2.circle(img, tuple(int(v) for v in port_px.ravel()), 10, (0, 255, 255), 2)
    hud = f"T+{t:4.0f}s  {phase}  nav sigma {nav.pos_sigma*100:4.1f} cm  " + ("CAMERA DROPOUT" if dropout else (pose.source if pose else "no fix"))
    cv2.rectangle(img, (0, img.shape[0] - 26), (img.shape[1], img.shape[0]), (10, 10, 10), -1)
    cv2.putText(img, hud, (8, img.shape[0] - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (230, 230, 230), 1, cv2.LINE_AA)
    return img


if __name__ == "__main__":
    main()
