// Offline closed-loop check of the C# navigation filter + guidance: port of tests/test_offline_closed_loop.py.
// Clohessy-Wiltshire truth, camera-fix noise as measured on real MDS frames, a camera dropout and a thruster misfire.
// Run: dotnet run --project Rpod.MonteCarlo
using System.Globalization;
using Rpod.Flight;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
double n = Orbit.MeanMotion(new Vec3(7630e3, 0, 0));

RunResult Run(int seed, double start = 14.0, (double T0, double T1)? dropout = null, (double T, Vec3 A)? misfire = null,
              double visionPeriod = 3.0, double maxT = 600)
{
    var rng = new Gaussian(seed);
    var axis = (new Vec3(0, -1, 0) + rng.Vec(0.02)).Unit;                       // port faces -V
    var lat = rng.Vec(0.06 * start);
    lat -= axis * lat.Dot(axis);
    var r0 = axis * start + lat;
    var v0 = rng.Vec(0.005);
    double[] x = [r0.X, r0.Y, r0.Z, v0.X, v0.Y, v0.Z];
    var p0 = r0 + rng.Vec(1.0);
    var nav = new RelNavFilter(n, [p0.X, p0.Y, p0.Z, 0, 0, 0], 2.0, 0.05);
    var g = new Guidance();
    double t = 0, lastFix = -1e9, nextVision = 0, dv = 0;
    while (t < maxT)
    {
        if (t >= nextVision)
        {
            nextVision = t + visionPeriod;
            double range = Vec3.From(x).Norm;
            bool dark = dropout is { } d && d.T0 <= t && t < d.T1;
            if (!dark && range > 2.7)                                           // below 2.7 m the marker leaves the view
            {
                double sigma = range > 10 ? 0.01 + 0.0015 * range * range : 0.01 + 0.002 * range;
                if (nav.UpdatePosition(Vec3.From(x) + rng.Vec(sigma), sigma)) lastFix = t;
            }
        }
        double along = Vec3.From(x).Dot(axis);
        if (along < 0.05)
        {
            double latErr = (Vec3.From(x) - along * axis).Norm, speed = Vec3.From(x, 3).Norm;
            return new RunResult(latErr < 0.10 && speed < 0.06, t, latErr * 100, speed * 100, dv, g.Events);
        }
        var a = g.Command(t, nav.X, axis, n, t - lastFix, nav.PosSigma);
        var aTrue = a * 1.02 + rng.Vec(2e-5);
        if (misfire is { } m && m.T <= t && t < m.T + 1) aTrue += m.A;
        x = Orbit.Propagate(n, x, aTrue, 1.0);
        nav.Predict(1.0, a);
        dv += a.Norm;
        t += 1.0;
    }
    return new RunResult(false, t, double.NaN, double.NaN, dv, g.Events);
}

int fails = 0;
var runs = Enumerable.Range(0, 50).Select(s => Run(s)).ToList();
var ok = runs.Where(r => r.Docked).ToList();
Console.WriteLine($"Monte Carlo, 50 runs from 14 m: {ok.Count}/50 docked; mean time {ok.Average(r => r.T):F0} s; " +
                  $"mean miss {ok.Average(r => r.LateralCm):F1} cm; mean contact speed {ok.Average(r => r.SpeedCms):F1} cm/s; " +
                  $"mean dv {ok.Average(r => r.DeltaV):F3} m/s; worst time {runs.Max(r => r.T):F0} s");
if (ok.Count < 50) fails++;

var drop = Run(3, dropout: (60, 120));
Console.WriteLine($"camera dropout 60-120 s: {drop.Docked} {drop.EventText} {drop.T:F0} s");
if (!drop.Docked) fails++;

var mis = Run(4, misfire: (40, new Vec3(0.08, 0.0, 0.05)));
Console.WriteLine($"thruster misfire at 40 s: {mis.Docked} {mis.EventText} {mis.T:F0} s");
if (!mis.Docked) fails++;

Console.WriteLine(fails == 0 ? "ALL PASSED" : $"{fails} FAILED");
return fails == 0 ? 0 : 1;

record RunResult(bool Docked, double T, double LateralCm, double SpeedCms, double DeltaV, IReadOnlyList<GuidanceEvent> Events)
{
    public string EventText => "[" + string.Join(", ", Events.Select(e => $"({e.T}, {e.Kind}, '{e.Why}')")) + "]";
}

/// <summary>Seeded normal random numbers (Box-Muller on System.Random).</summary>
sealed class Gaussian(int seed)
{
    private readonly Random _rng = new(seed);
    public double Next(double sigma = 1)
    {
        double u1 = 1.0 - _rng.NextDouble(), u2 = _rng.NextDouble();
        return sigma * Math.Sqrt(-2 * Math.Log(u1)) * Math.Cos(2 * Math.PI * u2);
    }
    public Vec3 Vec(double sigma) => new(Next(sigma), Next(sigma), Next(sigma));
}
