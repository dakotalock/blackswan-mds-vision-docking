using System.Text.Json;

namespace Rpod.Flight.Tests;

/// <summary>Reads tests/parity_fixtures.json (made by tools/make_parity_fixtures.py from the Python flight software).</summary>
public static class Fixtures
{
    private static readonly Lazy<JsonElement> Root = new(() =>
        JsonDocument.Parse(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "parity_fixtures.json"))).RootElement);

    public static JsonElement Get(string name) => Root.Value.GetProperty(name);
    public static double N => Root.Value.GetProperty("n").GetDouble();

    public static double[] Vector(JsonElement e) => e.EnumerateArray().Select(v => v.GetDouble()).ToArray();
    public static Vec3 V3(JsonElement e) => Vec3.From(Vector(e));

    public static double[,] Matrix(JsonElement e)
    {
        var rows = e.EnumerateArray().Select(Vector).ToArray();
        var m = new double[rows.Length, rows[0].Length];
        for (int i = 0; i < rows.Length; i++)
            for (int j = 0; j < rows[i].Length; j++) m[i, j] = rows[i][j];
        return m;
    }

    public static double MaxAbsDiff(double[,] a, double[,] b)
    {
        double d = 0;
        for (int i = 0; i < a.GetLength(0); i++)
            for (int j = 0; j < a.GetLength(1); j++) d = Math.Max(d, Math.Abs(a[i, j] - b[i, j]));
        return d;
    }

    public static double MaxAbsDiff(double[] a, double[] b) => a.Zip(b, (x, y) => Math.Abs(x - y)).Max();

    public static double MaxAbs(double[,] a) => a.Cast<double>().Max(Math.Abs);
}
