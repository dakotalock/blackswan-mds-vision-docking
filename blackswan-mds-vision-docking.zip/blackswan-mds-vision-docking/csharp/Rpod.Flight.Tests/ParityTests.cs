using System.Text.Json;

namespace Rpod.Flight.Tests;

/// <summary>The C# port must reproduce the Python flight software's numbers (to floating-point rounding).</summary>
public class ParityTests
{
    [Fact]
    public void LvlhFrameAndMeanMotion()
    {
        var f = Fixtures.Get("lvlh");
        var r = Fixtures.V3(f.GetProperty("r"));
        var v = Fixtures.V3(f.GetProperty("v"));
        Assert.True(Fixtures.MaxAbsDiff(Orbit.LvlhRotation(r, v), Fixtures.Matrix(f.GetProperty("R"))) < 1e-15);
        Assert.Equal(f.GetProperty("n").GetDouble(), Orbit.MeanMotion(r), 15);
    }

    public static IEnumerable<object[]> StmCases() =>
        Fixtures.Get("cw_stm").EnumerateArray().Select((c, i) => new object[] { i });

    [Theory]
    [MemberData(nameof(StmCases))]
    public void ClohessyWiltshireTransitionMatrix(int caseIndex)
    {
        var c = Fixtures.Get("cw_stm")[caseIndex];
        var expected = Fixtures.Matrix(c.GetProperty("F"));
        var actual = Orbit.CwStm(Fixtures.N, c.GetProperty("dt").GetDouble());
        Assert.True(Fixtures.MaxAbsDiff(actual, expected) <= 1e-12 * Fixtures.MaxAbs(expected));
    }

    [Fact]
    public void NaturalRelativeAcceleration()
    {
        foreach (var c in Fixtures.Get("cw_accel").EnumerateArray())
        {
            var a = Orbit.CwAccel(Fixtures.Vector(c.GetProperty("x")), Fixtures.N);
            Assert.True(Fixtures.MaxAbsDiff(a.ToArray(), Fixtures.Vector(c.GetProperty("a"))) < 1e-18);
        }
    }

    [Fact]
    public void KalmanFilterStepByStep()
    {
        var f = Fixtures.Get("filter");
        var nav = new RelNavFilter(Fixtures.N, Fixtures.Vector(f.GetProperty("x0")),
            f.GetProperty("pos_sigma").GetDouble(), f.GetProperty("vel_sigma").GetDouble());
        foreach (var s in f.GetProperty("steps").EnumerateArray())
        {
            nav.Predict(s.GetProperty("dt").GetDouble(), Fixtures.V3(s.GetProperty("accel")));
            if (s.TryGetProperty("z", out var z))
                Assert.Equal(s.GetProperty("accepted").GetBoolean(), nav.UpdatePosition(Fixtures.V3(z), s.GetProperty("sigma").GetDouble()));
            Assert.True(Fixtures.MaxAbsDiff(nav.X, Fixtures.Vector(s.GetProperty("x"))) < 1e-12);
            var p = Fixtures.Matrix(s.GetProperty("P"));
            Assert.True(Fixtures.MaxAbsDiff(nav.P, p) <= 1e-10 * Fixtures.MaxAbs(p));
            Assert.Equal(s.GetProperty("pos_sigma").GetDouble(), nav.PosSigma, 12);
        }
    }

    [Fact]
    public void GuidanceCommandsPhasesAndEventLog()
    {
        var g = new Guidance();
        foreach (var c in Fixtures.Get("guidance").EnumerateArray())
        {
            var a = g.Command(c.GetProperty("t").GetDouble(), Fixtures.Vector(c.GetProperty("x")), Fixtures.V3(c.GetProperty("axis")),
                Fixtures.N, c.GetProperty("since_fix").GetDouble(), c.GetProperty("pos_sigma").GetDouble());
            Assert.True(Fixtures.MaxAbsDiff(a.ToArray(), Fixtures.Vector(c.GetProperty("accel"))) < 1e-15);
            Assert.Equal(c.GetProperty("phase").GetString(), Guidance.PhaseName(g.Phase));
            var expected = c.GetProperty("events").EnumerateArray()
                .Select(e => new GuidanceEvent(e[0].GetDouble(), e[1].GetString()!, e[2].GetString()!)).ToList();
            Assert.Equal(expected, g.Events);              // records compare by value, text included
        }
    }

    [Fact]
    public void CompleteClosedLoopDockingRun()
    {
        var c = Fixtures.Get("closed_loop");
        var noise = c.GetProperty("noise");
        var trace = c.GetProperty("trace").EnumerateArray().ToList();
        var expected = c.GetProperty("result");
        var result = ClosedLoop.Run(Fixtures.N, noise, trace);
        Assert.Equal(expected.GetProperty("t").GetDouble(), result.T);
        Assert.Equal(expected.GetProperty("lateral_m").GetDouble(), result.LateralM, 12);
        Assert.Equal(expected.GetProperty("speed_mps").GetDouble(), result.SpeedMps, 12);
        Assert.Equal(expected.GetProperty("dv").GetDouble(), result.DeltaV, 12);
        Assert.Equal(expected.GetProperty("events").EnumerateArray().Select(e => e[1].GetString()), result.Events.Select(e => e.Kind));
    }
}

/// <summary>The offline test's closed loop, driven by the stored random draws; checks every step against the trace.</summary>
public static class ClosedLoop
{
    public sealed record Result(double T, double LateralM, double SpeedMps, double DeltaV, IReadOnlyList<GuidanceEvent> Events);

    public static Result Run(double n, JsonElement noise, List<JsonElement> trace)
    {
        var axis = Fixtures.V3(noise.GetProperty("axis"));
        var x = Fixtures.Vector(noise.GetProperty("x0"));
        var meas = noise.GetProperty("meas").EnumerateArray().Select(Fixtures.V3).ToArray();
        var thrust = noise.GetProperty("thrust").EnumerateArray().Select(Fixtures.V3).ToArray();
        var nav = new RelNavFilter(n, Fixtures.Vector(noise.GetProperty("nav_x0")), 2.0, 0.05);
        var g = new Guidance();
        double t = 0, lastFix = -1e9, nextVision = 0, dv = 0;
        int k = 0;
        for (int step = 0; t < 300; step++)
        {
            if (t >= nextVision)
            {
                nextVision = t + 4.0;
                double rr = Vec3.From(x).Norm;
                if (rr > 2.7)
                {
                    double sigma = rr > 10 ? 0.01 + 0.0015 * rr * rr : 0.01 + 0.002 * rr;
                    if (nav.UpdatePosition(Vec3.From(x) + sigma * meas[k], sigma)) lastFix = t;
                    k++;
                }
            }
            double along = Vec3.From(x).Dot(axis);
            if (along < 0.05)
                return new Result(t, (Vec3.From(x) - along * axis).Norm, Vec3.From(x, 3).Norm, dv, g.Events);
            var a = g.Command(t, nav.X, axis, n, t - lastFix, nav.PosSigma);
            var aTrue = a * 1.02 + 2e-5 * thrust[(int)t];
            x = Orbit.Propagate(n, x, aTrue, 1.0);
            nav.Predict(1.0, a);
            dv += a.Norm;
            t += 1.0;
            var s = trace[step];
            Assert.True(Fixtures.MaxAbsDiff(x, Fixtures.Vector(s.GetProperty("x"))) < 1e-9, $"truth differs at step {step}");
            Assert.True(Fixtures.MaxAbsDiff(nav.X, Fixtures.Vector(s.GetProperty("nav_x"))) < 1e-9, $"estimate differs at step {step}");
            Assert.Equal(s.GetProperty("phase").GetString(), Guidance.PhaseName(g.Phase));
        }
        throw new Xunit.Sdk.XunitException("no docking within 300 s");
    }
}
