namespace Rpod.Flight.Tests;

/// <summary>What the flight software must do, independent of the Python version.</summary>
public class BehaviourTests
{
    private static readonly double N = Orbit.MeanMotion(new Vec3(7630e3, 0, 0));
    private static readonly Vec3 Axis = new(0, -1, 0);    // docking port faces -V

    [Fact]
    public void Vec3Algebra()
    {
        var a = new Vec3(1, 2, 3);
        var b = new Vec3(-2, 0.5, 4);
        Assert.Equal(new Vec3(-1, 2.5, 7), a + b);
        Assert.Equal(0.0, a.Cross(b).Dot(a), 12);        // a x b is perpendicular to a
        Assert.Equal(1.0, b.Unit.Norm, 15);
    }

    [Fact]
    public void StateTransitionComposesOverTime()
    {
        // propagating 30 s then 70 s must equal propagating 100 s: F(100) = F(70) F(30)
        var f = Matrix.Multiply(Orbit.CwStm(N, 70), Orbit.CwStm(N, 30));
        Assert.True(Fixtures.MaxAbsDiff(f, Orbit.CwStm(N, 100)) < 1e-9);
    }

    [Fact]
    public void FilterRejectsASingleWildFixButRecoversFromARealJump()
    {
        var nav = new RelNavFilter(N, [0, -10, 0, 0, 0, 0], 0.02, 0.001);
        var jump = new Vec3(1.0, -10, 0);                  // 1 m away from a filter that believes 2 cm
        Assert.False(nav.UpdatePosition(jump, 0.02));
        Assert.False(nav.UpdatePosition(jump, 0.02));
        Assert.True(nav.UpdatePosition(jump, 0.02));       // third in a row: the filter, not the sensor, is wrong
        Assert.True(Math.Abs(nav.X[0] - 1.0) < 0.05);
    }

    [Fact]
    public void AccelerationIsLimited()
    {
        var g = new Guidance();
        var a = g.Command(0, [0, -14, 0, 0, 0.5, 0], Axis, N, 0);   // closing far too fast
        Assert.True(a.Norm <= g.MaxAccel + 1e-15);
    }

    [Fact]
    public void AbortsOutsideTheCorridorAndBacksAway()
    {
        var g = new Guidance();
        var a = g.Command(5, [3, -8, 0, 0, 0, 0], Axis, N, 0);      // 20 deg off the docking axis, inside 15 m
        Assert.Equal(Phase.Abort, g.Phase);
        Assert.Contains("outside the approach corridor", g.Events.Single().Why);
        Assert.True(a.Dot(Axis) > 0);                                // accelerating back out along the axis
    }

    [Fact]
    public void CommitsToTheFinalApproachWhenTheMarkerLeavesTheView()
    {
        var g = new Guidance();
        g.Command(60, [0.01, -2.0, 0, 0, 0.05, 0], Axis, N, sinceFix: 14, posSigma: 0.02);
        Assert.Equal(Phase.Approach, g.Phase);
        Assert.True(g.Committed);
        g.Command(70, [0.01, -1.5, 0, 0, 0.05, 0], Axis, N, sinceFix: 24, posSigma: 0.06);
        Assert.Equal(Phase.Approach, g.Phase);                       // still committed, no second event
        Assert.Single(g.Events);
        g.Command(160, [0.01, -0.5, 0, 0, 0.05, 0], Axis, N, sinceFix: 114, posSigma: 0.2);
        Assert.Equal(Phase.Abort, g.Phase);                          // but not forever: 90 s without a fix aborts
        Assert.Contains("coasted", g.Events.Last().Why);
    }

    [Fact]
    public void LosingTheMarkerFarOutAborts()
    {
        var g = new Guidance();
        g.Command(30, [0.05, -8.0, 0, 0, 0.1, 0], Axis, N, sinceFix: 13, posSigma: 0.02);
        Assert.Equal(Phase.Abort, g.Phase);
        Assert.Equal("no navigation fix for 13 s", g.Events.Single().Why);
    }
}
