using System.Globalization;

namespace Rpod.Flight;

public enum Phase { Approach, Abort }

/// <summary>A mission event, as logged by the Python version: (time, kind, reason).</summary>
public sealed record GuidanceEvent(double T, string Kind, string Why);

/// <summary>
/// Straight-line approach along the target's docking axis, slowing as it closes, with a safety monitor that aborts
/// (approach corridor, loss of navigation) and backs off, then tries again. Port of util_vision_nav.Guidance.
/// </summary>
public sealed class Guidance
{
    // init-only properties: settable in an object initializer (new Guidance { CorridorDeg = 8 }), then fixed
    public double CorridorDeg { get; init; } = 10.0;
    public double KeepOutM { get; init; } = 15.0;
    public double FinalSpeed { get; init; } = 0.03;      // m/s at contact
    public double MaxSpeed { get; init; } = 0.20;
    public double MaxAccel { get; init; } = 0.01;        // m/s^2
    public double RetreatToM { get; init; } = 12.0;
    public double LostLockS { get; init; } = 12.0;
    public double CommitRangeM { get; init; } = 3.0;     // committed final approach: inside this range, with a converged
    public double CommitSigmaM { get; init; } = 0.05;    // filter, losing sight of the marker is expected; the chaser
    public double CommitCoastS { get; init; } = 90.0;    // finishes on inertial navigation for up to this long

    public Phase Phase { get; private set; } = Phase.Approach;
    public bool Committed { get; private set; }
    public List<GuidanceEvent> Events { get; } = [];

    public static string PhaseName(Phase p) => p == Phase.Approach ? "APPROACH" : "ABORT";

    /// <summary>
    /// Acceleration command in LVLH. x: chaser port relative to target port [x y z vx vy vz]; axis: the target's
    /// docking axis (out of the port, toward the chaser).
    /// </summary>
    public Vec3 Command(double t, double[] x, Vec3 axis, double n, double sinceFix, double posSigma = 1.0)
    {
        var r = Vec3.From(x);
        var v = Vec3.From(x, 3);
        double along = r.Dot(axis);
        Vec3 lateral = r - along * axis;
        double offAxis = Math.Atan2(lateral.Norm, Math.Max(along, 1e-6)) * 180 / Math.PI;
        double range = r.Norm;

        if (Phase == Phase.Approach)
        {
            if (range < KeepOutM && offAxis > CorridorDeg && range > 1.0)
                Switch(t, Phase.Abort, $"outside the approach corridor ({F(offAxis, 1)} deg)");
            else if (sinceFix > LostLockS && range < KeepOutM)
            {
                bool committed = range < CommitRangeM && posSigma < CommitSigmaM + 0.002 * sinceFix;
                if (!committed)
                    Switch(t, Phase.Abort, $"no navigation fix for {F(sinceFix, 0)} s");
                else if (sinceFix > CommitCoastS)
                    Switch(t, Phase.Abort, $"final approach coasted {F(sinceFix, 0)} s without a fix");
                else if (!Committed)
                {
                    Committed = true;
                    Events.Add(new GuidanceEvent(Math.Round(t, 1), "COMMITTED",
                        $"marker out of view at {F(range, 1)} m; finishing on inertial navigation"));
                }
            }
        }
        if (Phase == Phase.Abort && along > RetreatToM && sinceFix < 3)
            Switch(t, Phase.Approach, "safe hold reached and target re-acquired: approaching again");

        Vec3 vCmd = Phase switch
        {
            Phase.Approach => -Math.Clamp(0.02 * along + FinalSpeed, FinalSpeed, MaxSpeed) * axis - 0.05 * lateral,
            _ => 0.1 * axis - 0.03 * lateral,                    // ABORT: back away along the axis
        };
        Vec3 a = 0.2 * (vCmd - v) - Orbit.CwAccel(x, n);
        double na = a.Norm;
        return na <= MaxAccel ? a : a * (MaxAccel / na);
    }

    private void Switch(double t, Phase phase, string why)
    {
        Phase = phase;
        Events.Add(new GuidanceEvent(Math.Round(t, 1), PhaseName(phase), why));
    }

    private static string F(double v, int decimals) => v.ToString("F" + decimals, CultureInfo.InvariantCulture);
}
