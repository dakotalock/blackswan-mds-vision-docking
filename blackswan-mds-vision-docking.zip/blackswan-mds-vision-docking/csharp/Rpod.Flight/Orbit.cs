namespace Rpod.Flight;

/// <summary>Orbital frames and Clohessy-Wiltshire relative motion (port of util_vision_nav.py).</summary>
public static class Orbit
{
    public const double EarthMu = 3.986004418e14;   // m^3/s^2

    /// <summary>Rows are the LVLH axes (x radial, y along-track, z orbit normal) in the inertial frame: p_lvlh = R p_inertial.</summary>
    public static double[,] LvlhRotation(Vec3 r, Vec3 v)
    {
        Vec3 x = r.Unit, z = r.Cross(v).Unit, y = z.Cross(x);
        return new[,] { { x.X, x.Y, x.Z }, { y.X, y.Y, y.Z }, { z.X, z.Y, z.Z } };
    }

    public static double MeanMotion(Vec3 r, double mu = EarthMu) => Math.Sqrt(mu / Math.Pow(r.Norm, 3));

    /// <summary>Clohessy-Wiltshire state transition matrix over t seconds; state [x y z vx vy vz] in LVLH.</summary>
    public static double[,] CwStm(double n, double t)
    {
        double s = Math.Sin(n * t), c = Math.Cos(n * t), nt = n * t;
        return new[,]
        {
            { 4 - 3 * c,        0, 0,      s / n,             2 * (1 - c) / n,       0 },
            { 6 * (s - nt),     1, 0,      2 * (c - 1) / n,   (4 * s - 3 * nt) / n,  0 },
            { 0,                0, c,      0,                 0,                     s / n },
            { 3 * n * s,        0, 0,      c,                 2 * s,                 0 },
            { 6 * n * (c - 1),  0, 0,      -2 * s,            4 * c - 3,             0 },
            { 0,                0, -n * s, 0,                 0,                     c },
        };
    }

    /// <summary>x(t+dt) = F x + B a, with constant acceleration a over the step.</summary>
    public static double[] Propagate(double n, double[] x, Vec3 a, double dt)
    {
        var xf = Matrix.Multiply(CwStm(n, dt), x);
        for (int i = 0; i < 3; i++)
        {
            xf[i] += 0.5 * dt * dt * a[i];
            xf[i + 3] += dt * a[i];
        }
        return xf;
    }

    /// <summary>Natural relative acceleration (gravity gradient + Coriolis) that the controller cancels.</summary>
    public static Vec3 CwAccel(double[] x, double n) =>
        new(3 * n * n * x[0] + 2 * n * x[4], -2 * n * x[3], -n * n * x[2]);
}
