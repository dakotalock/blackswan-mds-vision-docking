namespace Rpod.Flight;

/// <summary>Small dense matrix helpers for the 3x3 / 6x6 problems of relative navigation (row-major double[,]).</summary>
public static class Matrix
{
    public static double[,] Identity(int n)
    {
        var m = new double[n, n];
        for (int i = 0; i < n; i++) m[i, i] = 1;
        return m;
    }

    public static double[,] Multiply(double[,] a, double[,] b)
    {
        int n = a.GetLength(0), k = a.GetLength(1), m = b.GetLength(1);
        if (b.GetLength(0) != k) throw new ArgumentException("inner dimensions differ");
        var c = new double[n, m];
        for (int i = 0; i < n; i++)
            for (int p = 0; p < k; p++)
            {
                double aip = a[i, p];
                if (aip == 0) continue;
                for (int j = 0; j < m; j++) c[i, j] += aip * b[p, j];
            }
        return c;
    }

    public static double[] Multiply(double[,] a, double[] v)
    {
        int n = a.GetLength(0), m = a.GetLength(1);
        var r = new double[n];
        for (int i = 0; i < n; i++)
        {
            double s = 0;
            for (int j = 0; j < m; j++) s += a[i, j] * v[j];
            r[i] = s;
        }
        return r;
    }

    public static double[,] Transpose(double[,] a)
    {
        int n = a.GetLength(0), m = a.GetLength(1);
        var t = new double[m, n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++) t[j, i] = a[i, j];
        return t;
    }

    /// <summary>Gauss-Jordan inverse with partial pivoting.</summary>
    public static double[,] Inverse(double[,] a)
    {
        int n = a.GetLength(0);
        var m = new double[n, 2 * n];
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++) m[i, j] = a[i, j];
            m[i, n + i] = 1;
        }
        for (int c = 0; c < n; c++)
        {
            int p = c;
            for (int r = c + 1; r < n; r++) if (Math.Abs(m[r, c]) > Math.Abs(m[p, c])) p = r;
            if (Math.Abs(m[p, c]) < 1e-300) throw new InvalidOperationException("singular matrix");
            if (p != c)
                for (int j = 0; j < 2 * n; j++) (m[c, j], m[p, j]) = (m[p, j], m[c, j]);   // tuple swap
            double d = m[c, c];
            for (int j = 0; j < 2 * n; j++) m[c, j] /= d;
            for (int r = 0; r < n; r++)
            {
                if (r == c || m[r, c] == 0) continue;
                double f = m[r, c];
                for (int j = 0; j < 2 * n; j++) m[r, j] -= f * m[c, j];
            }
        }
        var inv = new double[n, n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++) inv[i, j] = m[i, n + j];
        return inv;
    }

    public static Vec3 Multiply(double[,] a, Vec3 v) =>
        new(a[0, 0] * v.X + a[0, 1] * v.Y + a[0, 2] * v.Z,
            a[1, 0] * v.X + a[1, 1] * v.Y + a[1, 2] * v.Z,
            a[2, 0] * v.X + a[2, 1] * v.Y + a[2, 2] * v.Z);
}
