namespace Rpod.Flight;

/// <summary>
/// Kalman filter on the chaser's docking port relative to the target's, in the target's LVLH frame [m, m/s].
/// Predicts with the Clohessy-Wiltshire equations; updates from camera position fixes with innovation gating.
/// </summary>
public sealed class RelNavFilter
{
    private readonly double _n;
    private readonly double _q;          // acceleration noise spectral density
    private int _rejections;

    public double[] X { get; private set; }
    public double[,] P { get; private set; }

    public RelNavFilter(double n, double[] x0, double posSigma, double velSigma, double accelNoise = 2e-4)
    {
        _n = n;
        X = (double[])x0.Clone();
        P = new double[6, 6];
        for (int i = 0; i < 3; i++) { P[i, i] = posSigma * posSigma; P[i + 3, i + 3] = velSigma * velSigma; }
        _q = accelNoise * accelNoise;
    }

    public void Predict(double dt, Vec3 accel)
    {
        var f = Orbit.CwStm(_n, dt);
        X = Orbit.Propagate(_n, X, accel, dt);
        var p = Matrix.Multiply(Matrix.Multiply(f, P), Matrix.Transpose(f));
        for (int i = 0; i < 3; i++)
        {
            p[i, i] += _q * dt * dt * dt / 3;
            p[i, i + 3] += _q * dt * dt / 2;
            p[i + 3, i] += _q * dt * dt / 2;
            p[i + 3, i + 3] += _q * dt;
        }
        P = p;
    }

    /// <summary>
    /// Position update with innovation gating. Three rejections in a row mean the filter, not the sensor, is wrong
    /// (an unmodelled push, say): the position covariance is re-inflated so the measurement can pull it back.
    /// </summary>
    /// <returns>true if the measurement was used.</returns>
    public bool UpdatePosition(Vec3 z, double sigma, double gate = 5.0)
    {
        var y = new[] { z.X - X[0], z.Y - X[1], z.Z - X[2] };
        var s = InnovationCovariance(sigma);
        var sInv = Matrix.Inverse(s);
        var sInvY = Matrix.Multiply(sInv, y);
        double mahalanobis2 = y[0] * sInvY[0] + y[1] * sInvY[1] + y[2] * sInvY[2];
        if (mahalanobis2 > gate * gate * 3)
        {
            _rejections++;
            if (_rejections < 3) return false;
            for (int i = 0; i < 3; i++)
            {
                P[i, i] += y[i] * y[i] + sigma * sigma;
                P[i + 3, i + 3] += 0.02 * 0.02;
            }
            sInv = Matrix.Inverse(InnovationCovariance(sigma));
        }
        _rejections = 0;

        // K = P H^T S^-1, with H = [I 0]: P H^T is the first three columns of P
        var k = new double[6, 3];
        for (int i = 0; i < 6; i++)
            for (int j = 0; j < 3; j++)
                k[i, j] = P[i, 0] * sInv[0, j] + P[i, 1] * sInv[1, j] + P[i, 2] * sInv[2, j];
        for (int i = 0; i < 6; i++) X[i] += k[i, 0] * y[0] + k[i, 1] * y[1] + k[i, 2] * y[2];

        var ikh = Matrix.Identity(6);
        for (int i = 0; i < 6; i++)
            for (int j = 0; j < 3; j++) ikh[i, j] -= k[i, j];
        var p = Matrix.Multiply(ikh, P);
        var sym = new double[6, 6];
        for (int i = 0; i < 6; i++)
            for (int j = 0; j < 6; j++) sym[i, j] = 0.5 * (p[i, j] + p[j, i]);
        P = sym;
        return true;
    }

    public double PosSigma => Math.Sqrt(P[0, 0] + P[1, 1] + P[2, 2]);

    private double[,] InnovationCovariance(double sigma)
    {
        var s = new double[3, 3];
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++) s[i, j] = P[i, j] + (i == j ? sigma * sigma : 0);
        return s;
    }
}
