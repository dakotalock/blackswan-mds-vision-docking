"""Plot a vision-docking run: python tools/plot_run.py examples/outputs/vision_docking_<time>"""
import csv, json, os, sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

d = sys.argv[1]
rows = list(csv.DictReader(open(os.path.join(d, "telemetry.csv"))))
f = lambda k: np.array([float(r[k]) if r[k] not in ("", "nan") else np.nan for r in rows])  # noqa: E731
t, rng, nav, sig, meas, axe, dv = f("t"), f("range_true"), f("nav_err_m"), f("nav_sigma_m"), f("meas_err_m"), f("axis_err_deg"), f("dv_mps")
phase = [r["phase"] for r in rows]
summary = json.load(open(os.path.join(d, "summary.json")))
fig, ax = plt.subplots(4, 1, figsize=(9, 11), sharex=True)
ax[0].plot(t, rng, color="#2563eb"); ax[0].set_ylabel("port-to-port range [m]"); ax[0].set_yscale("log")
for i in range(1, len(t)):
    if phase[i] != phase[i - 1]:
        for a in ax: a.axvline(t[i], color="#ef4444" if phase[i] == "ABORT" else "#16a34a", ls="--", lw=1)
        ax[0].text(t[i], ax[0].get_ylim()[1] * 0.7, " " + phase[i], color="#ef4444" if phase[i] == "ABORT" else "#16a34a", fontsize=8)
ax[1].plot(t, nav * 100, label="navigation error vs MDS truth", color="#f59e0b")
ax[1].plot(t, sig * 100, label="filter 1-sigma", color="#a3a3a3", ls=":")
ok = np.isfinite(meas)
ax[1].scatter(t[ok], meas[ok] * 100, s=8, label="single-frame camera fix error", color="#7c3aed")
ax[1].set_ylabel("error [cm]"); ax[1].set_yscale("log"); ax[1].legend(fontsize=8)
ax[2].plot(t, axe, color="#0891b2"); ax[2].set_ylabel("docking-axis error [deg]")
ax[3].plot(t, dv, color="#475569"); ax[3].set_ylabel("delta-v used [m/s]"); ax[3].set_xlabel("mission time [s]")
for te, kind, _ in summary.get("events", []):
    if kind == "COMMITTED":
        for a in ax: a.axvline(te, color="#7c3aed", ls="--", lw=1)
        ax[0].text(te, ax[0].get_ylim()[1] * 0.4, " COMMITTED (marker out of view)", color="#7c3aed", fontsize=8)
res = summary.get("docked")
if res:
    verdict = f"{'soft capture' if res['ok'] else 'hard contact'} at t={res['t']:.0f} s, {res['lateral_miss_m']*100:.1f} cm off axis, {res['contact_speed_mps']*100:.1f} cm/s"
else:
    verdict = "not docked"
fig.suptitle("Vision-in-the-loop docking in MDS: " + verdict, fontsize=11)
fig.tight_layout(); fig.savefig(os.path.join(d, "run_plots.png"), dpi=120)
print("wrote", os.path.join(d, "run_plots.png"))
