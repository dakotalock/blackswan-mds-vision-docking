// Build the password-locked static site for Netlify:  SITE_PASSWORD=... node tools/build_web.mjs  ->  web/dist/
//
// The app (page, styles, code and data) is bundled into one payload and encrypted with AES-256-GCM, the key derived
// from the password with PBKDF2-SHA256 (600 000 iterations, random salt). The published index.html holds only the
// lock screen and the ciphertext: nothing of the app is readable without the password (this is encryption, not a
// hidden page). The browser decrypts with its built-in Web Crypto API (Safari on iPhone included).
// The password is read from the environment and is not written anywhere.

import { webcrypto as crypto } from "node:crypto";
import { cpSync, mkdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const WEB = join(dirname(fileURLToPath(import.meta.url)), "..", "web");
const DIST = join(WEB, "dist");
const password = process.env.SITE_PASSWORD;
if (!password) { console.error("Set SITE_PASSWORD to build the site."); process.exit(1); }

// ---- 1. bundle the ES modules into one script (dependency order; relative imports and "export" removed) ----
const ORDER = ["linalg", "flight", "pose", "aruco", "mission", "scene", "main"];
const external = new Set(), seen = new Map();
let bundle = "";
for (const name of ORDER) {
  let src = readFileSync(join(WEB, "src", `${name}.js`), "utf8");
  src = src.replace(/^import\s+[^;]*?from\s+"(three[^"]*)";\s*$/gm, (m) => { external.add(m.trim()); return ""; });
  src = src.replace(/^import\s+[^;]*?from\s+"\.\/[^"]+";\s*$/gm, "");
  src = src.replace(/^export\s+\{[^}]*\};\s*$/gm, "");
  src = src.replace(/^export\s+(?=(async\s+)?(const|let|function|class)\b)/gm, "");
  for (const m of src.matchAll(/^(?:async\s+)?(?:const|let|function|class)\s+([A-Za-z_$][\w$]*)/gm)) {
    if (seen.has(m[1])) throw new Error(`top-level name "${m[1]}" is defined in both ${seen.get(m[1])}.js and ${name}.js`);
    seen.set(m[1], name);
  }
  if (/^\s*(import|export)\b/m.test(src)) throw new Error(`${name}.js: an import/export the bundler does not handle`);
  bundle += `\n// ===== ${name}.js =====\n${src}`;
}
bundle = [...external].join("\n") + "\n" + bundle;

// ---- 2. the payload: page fragment, styles, script, data ----
const payload = JSON.stringify({
  html: readFileSync(join(WEB, "app.html"), "utf8"),
  css: readFileSync(join(WEB, "style.css"), "utf8"),
  js: bundle,
  data: {
    cal: JSON.parse(readFileSync(join(WEB, "data", "calibration.json"), "utf8")),
    mdsCsv: readFileSync(join(WEB, "data", "mds_run.csv"), "utf8"),
    mdsSummary: JSON.parse(readFileSync(join(WEB, "data", "mds_summary.json"), "utf8")),
  },
});

// ---- 3. encrypt ----
const ITER = 600000;
const salt = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12));
const base = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveKey"]);
const key = await crypto.subtle.deriveKey({ name: "PBKDF2", salt, iterations: ITER, hash: "SHA-256" }, base, { name: "AES-GCM", length: 256 }, false, ["encrypt"]);
const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, new TextEncoder().encode(payload)));
const b64 = (u8) => Buffer.from(u8).toString("base64");

// ---- 4. write dist/: lock screen + ciphertext, and the three.js library (public, MIT) ----
rmSync(DIST, { recursive: true, force: true });
mkdirSync(DIST, { recursive: true });
cpSync(join(WEB, "vendor"), join(DIST, "vendor"), { recursive: true });
const gate = readFileSync(join(WEB, "gate.html"), "utf8")
  .replace("__PAYLOAD__", JSON.stringify({ v: 1, iter: ITER, salt: b64(salt), iv: b64(iv), ct: b64(ct) }));
writeFileSync(join(DIST, "index.html"), gate);
writeFileSync(join(DIST, "_headers"), "/*\n  X-Robots-Tag: noindex, nofollow\n  Referrer-Policy: no-referrer\n  X-Content-Type-Options: nosniff\n/index.html\n  Cache-Control: no-cache\n");
writeFileSync(join(DIST, "robots.txt"), "User-agent: *\nDisallow: /\n");
console.log(`built ${DIST}: app ${(payload.length / 1024).toFixed(0)} kB encrypted into index.html (${(gate.length / 1024).toFixed(0)} kB); ` +
  `${seen.size} top-level names, no collisions`);
