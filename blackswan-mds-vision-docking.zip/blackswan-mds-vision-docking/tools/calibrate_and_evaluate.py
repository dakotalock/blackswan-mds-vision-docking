"""Calibrate the fiducial target and the camera mount from MDS frames taken at known poses, then evaluate the
pose estimator on frames the calibration never saw.

  1. capture:   python tools/capture_known_poses.py <dir> 40      (MDS running)
  2. calibrate: python tools/calibrate_and_evaluate.py <dir>[,<dir2>...] [out.json]

Unknowns fitted on the even-numbered frames: the marker's side length and its pose on the target, and the camera's
position along the chaser's boresight. The odd-numbered frames are then used to measure the estimator's accuracy
against MDS truth (target docking-port position and docking-axis direction in the chaser frame).
"""
import json, os, sys
import cv2, numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation as Rot
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "examples"))
from utilities.util_vision_nav import CameraModel, FiducialTarget, estimate_pose  # noqa: E402

D = sys.argv[1]
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "examples", "data", "vision_docking_calibration.json")
vec = lambda s: np.fromstring(s.strip("()"), sep=", ")  # noqa: E731
cam = CameraModel()
unit = FiducialTarget(side_m=1.0)
frames = []
for d_i, DD in enumerate(D.split(",")):
  for m in json.load(open(f"{DD}/meta.json")):
    rgb = cv2.imread(f"{DD}/img_{m['k']:03d}.png")
    dep_path = f"{DD}/dep_{m['k']:03d}.npy"                      # depth frames are optional (only a cross-check)
    depth = np.load(dep_path).astype(float) if os.path.exists(dep_path) else np.full(rgb.shape[:2], np.nan)
    depth[depth <= 0] = np.nan
    m = dict(m, k=1000 * d_i + m["k"])
    c = unit.detect(rgb)
    frames.append(dict(m=m, rgb=rgb, depth=depth, corners=c, r_c=vec(m["r_c"]), R_wc=Rot.from_quat(vec(m["q_c"])).as_matrix(),
                       r_t=vec(m["r_t"]), R_wt=Rot.from_quat(vec(m["q_t"])).as_matrix()))
seen = [f for f in frames if f["corners"] is not None]
print(f"{len(frames)} frames, marker detected in {len(seen)}")
cal_set = [f for f in seen if f["m"]["k"] % 2 == 0]
test_set = [f for f in frames if f["m"]["k"] % 2 == 1]

# ---- calibration (even frames): fit every marker corner, in pixels, against MDS truth ----
# unknowns: marker pose on the target (rotation vector + centre), marker side, camera position in the chaser body,
#           a small camera mounting rotation, and the focal-length scale
def predict(p, f):
    rv_tm, c_tm, s, cam_off, rv_mount, fscale = p[0:3], p[3:6], p[6], p[7:10], p[10:13], p[13]
    R_tm = Rot.from_rotvec(rv_tm).as_matrix()
    R_bc = Rot.from_rotvec(rv_mount).as_matrix() @ cam.R_body_cam
    corners_t = (R_tm @ (unit.object_points() * s).T).T + c_tm                       # target frame
    corners_w = f["r_t"] + (f["R_wt"] @ corners_t.T).T
    corners_b = (f["R_wc"].T @ (corners_w - f["r_c"]).T).T - cam_off                    # chaser body, from the camera
    corners_c = (R_bc.T @ corners_b.T).T
    K = cam.K.copy(); K[0, 0] *= fscale; K[1, 1] *= fscale
    uv = (K @ corners_c.T).T
    return uv[:, :2] / uv[:, 2:3]
def resid(p):
    return np.concatenate([(predict(p, f) - f["corners"]).ravel() for f in cal_set])
# initial guess from a quick PnP on the first frame
p0 = np.zeros(14); p0[3:6] = [-1.2, -1.2, 2.5]; p0[6] = 1.3; p0[7] = 2.0; p0[13] = 1.0
best = None
for flip in ([0, 0, 0], [np.pi, 0, 0], [0, np.pi, 0], [0, 0, np.pi]):
    q = p0.copy(); q[0:3] = flip
    r = least_squares(resid, q, loss="soft_l1", f_scale=2.0)
    if best is None or r.cost < best.cost: best = r
p = best.x
rms = float(np.sqrt(np.mean(resid(p) ** 2)))
cam_off = p[7:10]; mount = Rot.from_rotvec(p[10:13])
cal = {"marker_side_m": float(p[6]), "cam_offset_body": cam_off.tolist(), "marker_center_target": p[3:6].tolist(),
       "R_target_marker": Rot.from_rotvec(p[0:3]).as_matrix().tolist(), "camera_mount_rotvec": p[10:13].tolist(),
       "focal_scale": float(p[13]), "fit_rms_px": rms, "fitted_on_frames": [f["m"]["k"] for f in cal_set]}
json.dump(cal, open(OUT, "w"), indent=1)
print(f"calibration on {len(cal_set)} frames: corner RMS {rms:.2f} px; marker side {p[6]:.3f} m at {np.round(p[3:6], 3)} in the target frame;")
print(f"  camera at {np.round(cam_off, 3)} m in the chaser body, mount tilt {np.degrees(np.linalg.norm(p[10:13])):.2f} deg, focal scale {p[13]:.4f}")

# ---- evaluation (odd frames, never used for calibration) ----
cam = CameraModel.from_calibration(cal)
target = FiducialTarget.from_json(OUT)
rows = []
rng = np.random.default_rng(0)
for f in test_set:
    port_true_c = f["R_wc"].T @ (f["r_t"] + f["R_wt"] @ target.port_target - f["r_c"])    # chaser body frame
    axis_true_c = f["R_wc"].T @ f["R_wt"] @ target.port_axis_target
    # navigation prior: the true axis blurred by 10 deg, standing in for the filter's prediction
    prior = Rot.from_rotvec(np.radians(10) * rng.normal(size=3) / np.sqrt(3)).apply(cam.R_body_cam.T @ axis_true_c)
    R_ct_true = cam.R_body_cam.T @ f["R_wc"].T @ f["R_wt"]
    prior_R = Rot.from_rotvec(np.radians(3) * rng.normal(size=3) / np.sqrt(3)).as_matrix() @ R_ct_true   # filter-quality attitude
    for use_depth in (False, True):
        pose = estimate_pose(f["rgb"], f["depth"] if use_depth else None, cam, target, prior_axis_cam=prior if use_depth else None, prior_R_ct=prior_R if use_depth else None)
        if pose is None:
            rows.append(dict(k=f["m"]["k"], d=f["m"]["d"], depth=use_depth, found=False)); continue
        port_est_c = cam.offset_body + cam.R_body_cam @ (pose.R_ct @ target.port_target + pose.t_ct)
        axis_est_c = cam.R_body_cam @ pose.R_ct @ target.port_axis_target
        rows.append(dict(k=f["m"]["k"], d=f["m"]["d"], depth=use_depth, found=True, source=pose.source,
                         pos_err=float(np.linalg.norm(port_est_c - port_true_c)),
                         axis_err=float(np.degrees(np.arccos(np.clip(axis_est_c @ axis_true_c, -1, 1)))), reproj=pose.reproj_px))
bands = [(0, 8, "4-8 m"), (8, 15, "8-15 m"), (15, 22, "15-22 m"), (22, 40, "22-30 m")]
print(f"\n{'range':9s} {'mode':13s} {'n':>3s} {'found':>6s} {'port pos err (mean / max)':>27s} {'axis err mean':>14s}")
table = []
for lo, hi, name in bands:
    for use_depth in (False, True):
        sel = [r for r in rows if lo <= r["d"] < hi and r["depth"] == use_depth]
        ok = [r for r in sel if r["found"]]
        if not sel: continue
        pe = [r["pos_err"] for r in ok]; ae = [r["axis_err"] for r in ok]
        line = dict(range=name, mode="with nav prior" if use_depth else "single frame", n=len(sel), found=len(ok),
                    pos_mean_cm=float(np.mean(pe) * 100) if pe else None, pos_max_cm=float(np.max(pe) * 100) if pe else None,
                    axis_mean_deg=float(np.mean(ae)) if ae else None)
        table.append(line)
        print(f"{name:9s} {line['mode']:13s} {len(sel):3d} {len(ok):6d} "
              + (f"{line['pos_mean_cm']:10.1f} cm / {line['pos_max_cm']:6.1f} cm {line['axis_mean_deg']:11.2f} deg" if pe else "      -"))
json.dump(dict(calibration=cal, evaluation=table, per_frame=rows), open(os.path.join(D.split(",")[-1], "evaluation.json"), "w"), indent=1)
