"""Reference numbers from the Python flight software, for checking the JavaScript (web/) and C# (csharp/) ports.

    python tools/make_parity_fixtures.py        ->  tests/parity_fixtures.json

Every random number a port would need is drawn here and stored, so a port that does the same math reproduces the
same numbers exactly (to floating-point rounding), including a complete closed-loop docking run.
"""
import json, os, sys
import numpy as np
from scipy.spatial.transform import Rotation as Rot
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
sys.path.insert(0, os.path.join(ROOT, "examples"))
from utilities.util_vision_nav import (CameraModel, FiducialTarget, Guidance, RelNavFilter, cw_accel, cw_stm,  # noqa: E402
                                       lvlh_rotation, mean_motion, pose_from_corners)

rng = np.random.default_rng(2026)
N = mean_motion(np.array([7630e3, 0, 0]))
L = lambda a: np.asarray(a, float).tolist()  # noqa: E731
out = {"n": N}

# ---- orbital frames and the Clohessy-Wiltshire state transition matrix ----
r, v = np.array([1200e3, -6100e3, 4400e3]), np.array([6.1e3, 2.2e3, 1.4e3])
out["lvlh"] = {"r": L(r), "v": L(v), "R": L(lvlh_rotation(r, v)), "n": mean_motion(r)}
out["cw_stm"] = [{"dt": dt, "F": L(cw_stm(N, dt))} for dt in (1.0, 4.0, 60.0, 900.0)]
out["cw_accel"] = [{"x": L(x), "a": L(cw_accel(x, N))} for x in rng.normal(0, [5, 5, 5, .1, .1, .1], (3, 6))]

# ---- Kalman filter: predicts, accepted updates, gated outliers and the re-inflation after three rejections ----
nav = RelNavFilter(N, np.array([0.4, 11.0, -0.3, 0, 0, 0]), 2.0, 0.05)
steps = []
truth = np.array([0.1, 10.0, 0.05])
for k in range(30):
    a = rng.normal(0, 2e-3, 3)
    nav.predict(1.0, a)
    step = {"op": "predict", "dt": 1.0, "accel": L(a)}
    if k % 3 == 0:
        z = truth + rng.normal(0, 0.03, 3)
        if 12 <= k <= 18:
            z = z + np.array([1.5, -2.0, 1.0])        # a jump the filter must first reject, then accept
        acc = nav.update_position(z, 0.03)
        step.update(op="predict+update", z=L(z), sigma=0.03, accepted=bool(acc))
    step.update(x=L(nav.x), P=L(nav.P), pos_sigma=nav.pos_sigma)
    steps.append(step)
out["filter"] = {"x0": [0.4, 11.0, -0.3, 0, 0, 0], "pos_sigma": 2.0, "vel_sigma": 0.05, "steps": steps}

# ---- Guidance and the safety monitor: approach, corridor abort, retreat, re-approach, committed final approach ----
g = Guidance()
axis = np.array([0.0, -1.0, 0.0])
calls = []
script = [  # (t, state, since_fix, pos_sigma)
    (0, [0.3, -10, 0.1, 0, 0.05, 0], 0, 0.3), (1, [0.3, -9.9, 0.1, 0, 0.1, 0], 1, 0.2),
    (2, [2.5, -8, 0.5, 0.01, 0.1, 0], 0, 0.05),                    # 18 deg off axis inside 15 m: ABORT
    (3, [2.4, -8.5, 0.5, 0, -0.05, 0], 1, 0.05), (40, [0.2, -12.5, 0.1, 0, -0.02, 0], 1, 0.04),   # re-approach
    (41, [0.2, -12.4, 0.1, 0, 0.1, 0], 2, 0.04), (60, [0.02, -2.5, 0.01, 0, 0.05, 0], 13, 0.03),  # COMMITTED
    (70, [0.01, -1.9, 0.01, 0, 0.05, 0], 23, 0.04), (80, [0, -8, 0, 0, 0.05, 0], 13, 0.06),          # lost lock: ABORT
    (81, [0, -0.5, 0, 0, 0.03, 0], 0, 0.01),
]
for t, x, since, sig in script:
    x = np.array(x, float)
    a = g.command(t, x, axis, N, since, sig)
    calls.append({"t": t, "x": L(x), "axis": L(axis), "since_fix": since, "pos_sigma": sig,
                  "accel": L(a), "phase": g.phase, "events": [[e[0], e[1], e[2]] for e in g.events]})
out["guidance"] = calls

# ---- Pose from the marker's four corners: both planar solutions, choice by the navigation prior, position-only mode ----
cal = json.load(open(os.path.join(ROOT, "examples", "data", "vision_docking_calibration.json")))
cam, target = CameraModel.from_calibration(cal), FiducialTarget(side_m=cal["marker_side_m"],
              center_target=np.array(cal["marker_center_target"]), R_target_marker=np.array(cal["R_target_marker"]))
import cv2  # noqa: E402
poses = []
for d, tilt, roll, prior in [(3.0, 8, 20, "axis"), (5.0, 15, -60, "axis"), (8.0, 4, 150, "none"), (12.0, 2, 90, "flipped"),
                             (6.0, 25, 10, "axis"), (18.0, 3, 45, "axis+R")]:
    R_ct = Rot.from_euler("xyz", [180 + tilt, rng.normal(0, 3), roll], degrees=True).as_matrix()   # target faces the camera
    port_cam = np.array([rng.normal(0, 0.05 * d), rng.normal(0, 0.05 * d), d])
    t_ct = port_cam - R_ct @ target.port_target
    R_cm = R_ct @ target.R_target_marker
    t_cm = R_ct @ target.center_target + t_ct
    px, _ = cv2.projectPoints(target.object_points(), cv2.Rodrigues(R_cm)[0], t_cm, cam.K, None)
    corners = px.reshape(4, 2) + rng.normal(0, 0.2, (4, 2))
    axis_cam = R_ct @ target.port_axis_target
    prior_axis = {"axis": axis_cam, "none": None, "flipped": None, "axis+R": axis_cam}[prior]
    if prior == "flipped":                            # a prior that prefers the mirror-image solution
        prior_axis = axis_cam - 2 * (axis_cam @ (t_cm / np.linalg.norm(t_cm))) * t_cm / np.linalg.norm(t_cm)
        prior_axis = -prior_axis
    prior_R = R_ct if prior == "axis+R" else None
    pose = pose_from_corners(corners, cam, target, prior_axis, prior_R)
    poses.append({"range": d, "corners": L(corners), "prior_axis_cam": None if prior_axis is None else L(prior_axis),
                  "prior_R_ct": None if prior_R is None else L(prior_R), "truth_R_ct": L(R_ct), "truth_t_ct": L(t_ct),
                  "R_ct": L(pose.R_ct), "t_ct": L(pose.t_ct), "reproj_px": pose.reproj_px, "source": pose.source,
                  "marker_px": pose.marker_px})
out["pose"] = {"K": L(cam.K), "R_body_cam": L(cam.R_body_cam), "cam_offset_body": L(cam.offset_body),
               "marker_side_m": target.side_m, "marker_center_target": L(target.center_target),
               "R_target_marker": L(target.R_target_marker), "port_target": L(target.port_target), "cases": poses}

# ---- A complete closed-loop docking run (the offline test's loop) with every random draw stored ----
def closed_loop(noise, start=10.0, vision_period=4.0, max_t=300):
    axis = np.array(noise["axis"], float)
    x = np.array(noise["x0"], float)
    nav = RelNavFilter(N, np.array(noise["nav_x0"], float), 2.0, 0.05)
    g = Guidance(); t, last_fix, next_v, dv, k_meas = 0.0, -1e9, 0.0, 0.0, 0
    trace = []
    while t < max_t:
        if t >= next_v:
            next_v = t + vision_period
            rr = np.linalg.norm(x[:3])
            if rr > 2.7:
                sigma = 0.01 + 0.0015 * rr ** 2 if rr > 10 else 0.01 + 0.002 * rr
                if nav.update_position(x[:3] + sigma * np.array(noise["meas"][k_meas]), sigma):
                    last_fix = t
                k_meas += 1
        along = x[:3] @ axis
        if along < 0.05:
            lat = np.linalg.norm(x[:3] - along * axis)
            return trace, dict(t=t, lateral_m=lat, speed_mps=float(np.linalg.norm(x[3:])), dv=dv, events=g.events)
        a = g.command(t, nav.x, axis, N, t - last_fix, nav.pos_sigma)
        a_true = a * 1.02 + 2e-5 * np.array(noise["thrust"][int(t)])
        F = cw_stm(N, 1.0); B = np.vstack([0.5 * np.eye(3), np.eye(3)])
        x = F @ x + B @ a_true
        nav.predict(1.0, a); dv += float(np.linalg.norm(a)); t += 1.0
        trace.append({"t": t, "x": L(x), "nav_x": L(nav.x), "accel": L(a), "phase": g.phase})
    return trace, dict(t=t, timeout=True)

axis = np.array([0.0, -1.0, 0.0]) + rng.normal(0, 0.02, 3); axis /= np.linalg.norm(axis)
lat = rng.normal(0, 0.06 * 10, 3); lat -= axis * (lat @ axis)
x0 = np.concatenate([axis * 10 + lat, rng.normal(0, 0.005, 3)])
noise = {"axis": L(axis), "x0": L(x0), "nav_x0": L(np.concatenate([x0[:3] + rng.normal(0, 1.0, 3), np.zeros(3)])),
         "meas": L(rng.normal(0, 1, (200, 3))), "thrust": L(rng.normal(0, 1, (400, 3)))}
trace, result = closed_loop(noise)
out["closed_loop"] = {"noise": noise, "trace": trace, "result": {**result, "events": [list(e) for e in result["events"]]}}

path = os.path.join(ROOT, "tests", "parity_fixtures.json")
json.dump(out, open(path, "w"))
print("wrote", path, f"({os.path.getsize(path) / 1e3:.0f} kB); closed loop:",
      f"docked at t={result['t']:.0f} s, {result['lateral_m'] * 100:.1f} cm off axis, {result['speed_mps'] * 100:.1f} cm/s")
print("guidance phases:", [c["phase"] for c in calls])
print("filter accepted:", [s.get("accepted") for s in steps if "accepted" in s])
print("pose sources:", [(p["range"], p["source"], round(float(np.linalg.norm(np.array(p["t_ct"]) - p["truth_t_ct"])) * 100, 1)) for p in poses])
