"""Capture MDS RGB + depth frames at known chaser poses along the target's docking axis (+Z of the target body),
in the same configuration as demo_vision_docking.py (DockChaser model, camera at distance_from_satellite=-1.91).

    python tools/capture_known_poses.py <out_dir> <n_frames> [min_range max_range [seed [--roll]]]
Run from the Help_API_and_Examples/examples folder, with MDS open.

--roll turns the chaser to a random roll about its boresight in every frame. With a fixed roll, a sideways error in
the camera's mounting position looks exactly like a sideways error in the marker's position on the target, so the
calibration cannot tell them apart; frames at many rolls separate the two."""
import time, sys, json, cv2, numpy as np
sys.path.insert(0, ".")
from mds_api import mds_api
import utilities.util_attitude as att
from scipy.spatial.transform import Rotation as Rot
OUT, N = sys.argv[1], int(sys.argv[2])
R_MIN, R_MAX = (float(sys.argv[3]), float(sys.argv[4])) if len(sys.argv) > 4 else (3.0, 16.0)
P = lambda *a: print(time.strftime("%H:%M:%S"), *a, flush=True)
vec = lambda s: np.fromstring(s.strip('()'), sep=', ')
rng = np.random.default_rng(int(sys.argv[5]) if len(sys.argv) > 5 else 7)
ROLL = "--roll" in sys.argv
a, e, i, w, raan, ta = 7630e3, 0.0001, 100.7, 0, 120, 90
PORT = np.array([0, 0, 3.18])
mds_api.clear_scene(); mds_api.enable_API_synchronization()
mds_api.set_utc_date(2026, 6, 13, 11, 59, 59, 0)
q_target = Rot.from_euler("xyz", [8, -5, 12], degrees=True).as_quat()   # some attitude, not axis-aligned
mds_api.add_sat_from_elements("target", 4000, a, e, i, raan, w, ta, 'Earth', attitude=q_target,
      custom_model_path='/CustomModels/GEOSAT/GEOSAT_original_real-size_docking.glb', rigidbody=True)
mds_api.add_sat_from_elements("chaser", 2000, a, e, i, raan, w, ta - 0.01, 'Earth', rigidbody=True,
      custom_model_path="/CustomModels/chaser/DockChaser_BSS.glb")
time.sleep(0.5)
mds_api.attach_camera_to_sat("chaser", focal_length=20.7, near_plane=0.2, far_plane=1e8, distance_from_satellite=-1.91,
      texture_width=640, texture_height=480)
mds_api.select_satellite("chaser")
jd, t = mds_api.get_sat_data("target")
r_t, v_t, q_t = vec(t['localPosition']), vec(t['localVelocity']), vec(t['attitudeState']['attitude'])
Rt = Rot.from_quat(q_t); port_w = r_t + Rt.apply(PORT); axis_w = Rt.apply([0, 0, 1])
P("target q from MDS", np.round(q_t, 4), "requested", np.round(q_target, 4))
meta = []
for k in range(N):
    d = rng.uniform(R_MIN, R_MAX)
    lat = rng.normal(0, 0.08 * d, 2)
    ex = Rt.apply([1, 0, 0]); ey = Rt.apply([0, 1, 0])
    r_c = port_w + axis_w * d + ex * lat[0] + ey * lat[1]
    up = ey if abs(np.dot(ey, axis_w)) < 0.9 else ex
    R = att.get_rot_x_aligned(port_w - r_c, up) * Rot.from_euler("zyx", rng.normal(0, 2.0, 3), degrees=True)
    if ROLL:
        R = R * Rot.from_euler("x", rng.uniform(-180, 180), degrees=True)
    mds_api.set_sat_position("chaser", r_c); mds_api.set_sat_velocity("chaser", v_t)
    mds_api.set_pointing_mode("chaser", "CustomQuaternion"); mds_api.set_pointing_target("chaser", R.as_quat())
    mds_api.set_sat_attitude("chaser", R.as_quat()); time.sleep(0.8)
    dep = np.frombuffer(mds_api.get_camera_depth_frame("chaser"), np.float32).reshape(480, 640)
    img = cv2.imdecode(np.frombuffer(mds_api.get_camera_frame("chaser", delay=True), np.uint8), cv2.IMREAD_COLOR)
    _, c = mds_api.get_sat_data("chaser"); _, t = mds_api.get_sat_data("target")
    cv2.imwrite(f"{OUT}/img_{k:03d}.png", img); np.save(f"{OUT}/dep_{k:03d}.npy", dep)
    meta.append({"k": k, "d": d, "r_c": c['localPosition'], "q_c": c['attitudeState']['attitude'],
                 "r_t": t['localPosition'], "q_t": t['attitudeState']['attitude']})
    json.dump(meta, open(f"{OUT}/meta.json", "w"), indent=1)
    P(k, f"d={d:.1f}", "ok")
