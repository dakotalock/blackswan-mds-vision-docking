// The closed loop of examples/demo_vision_docking.py (CwPlant mode), step for step:
//   camera frame -> marker corners -> pose -> port-to-port measurement -> Kalman filter -> guidance -> thrusters,
// with truth (Clohessy-Wiltshire relative motion, 2 % thrust scale error, thrust noise, 0.1 deg pointing jitter)
// kept separate from the flight software and used only for scoring.
//
// The world frame here is the target's LVLH frame (x radial, y along-track, z orbit normal), so the chaser's
// LVLH rotation R_lvlh of the Python version is the identity. The camera is a callback: in the browser it renders
// the scene with three.js and runs the ArUco detector on the pixels; in the tests it ray-traces a synthetic image.

import { cwPropagate, Guidance, meanMotion, RelNavFilter, xAligned } from "./flight.js";
import { euler, fromColumns, gauss, mul, mulVec, rotvec, seeded, transpose, v3 } from "./linalg.js";
import { CameraModel, FiducialTarget, poseFromCorners } from "./pose.js";

export const PORT_CHASER = [2.12, 0, 0];                 // chaser docking port, body frame (DockChaser_BSS model)
export const R_LT = fromColumns([-1, 0, 0], [0, 0, -1], [0, -1, 0]);   // target body -> LVLH: docking port faces -V
export const ORBIT_A = 7630e3;                            // same orbit as MDS's demo_gnc_docking.py
export const TELEMETRY_COLUMNS = ["t", "phase", "range_true", "rx_est", "ry_est", "rz_est", "rx_true", "ry_true", "rz_true",
  "vx_true", "vy_true", "vz_true", "nav_err_m", "nav_sigma_m", "meas_err_m", "axis_err_deg", "fix", "dv_mps"];

const deg = Math.PI / 180;
const r4 = (x) => Math.round(x * 1e4) / 1e4;

export class Mission {
  /**
   * @param cal     calibration JSON (camera mount + marker placement), as examples/data/vision_docking_calibration.json
   * @param opts    { startRange, visionPeriod, finalVisionPeriod, dt, maxTime, seed, dropout: [t0, t1], misfire: [t, [ax, ay, az]],
   *                  x0: optional initial truth [x, y, z] (port to port, LVLH) }
   * @param camera  (cameraPositionLvlh, R_lvlh_from_camera_opencv) -> { corners | null, ... } — the camera + detector
   */
  constructor(cal, opts, camera) {
    this.opts = { startRange: 10, visionPeriod: 4, finalVisionPeriod: 10, dt: 1, maxTime: 560, seed: 2, dropout: null, misfire: null, ...opts };
    this.cam = new CameraModel(cal);
    this.target = new FiducialTarget(cal);
    this.camera = camera;
    this.rng = seeded(this.opts.seed);
    const N = (s = 1) => gauss(this.rng) * s;
    this.n = meanMotion([ORBIT_A, 0, 0]);

    // scene set-up (not navigation): chaser start_range out along the docking axis, small lateral offset and pointing error
    this.portT = mulVec(R_LT, this.target.portTarget);
    this.axisL = mulVec(R_LT, this.target.portAxisTarget);
    const range = this.opts.startRange;
    let lateral = [N(0.06 * range), N(0.06 * range), N(0.06 * range)];
    lateral = v3.sub(lateral, v3.scale(this.axisL, v3.dot(lateral, this.axisL)));
    let rPort0 = v3.add(this.portT, v3.add(v3.scale(this.axisL, range), lateral));
    if (this.opts.x0) rPort0 = v3.add(this.portT, this.opts.x0);
    const rC0 = v3.add(rPort0, v3.scale(this.axisL, PORT_CHASER[0]));
    this.R_c = mul(xAligned(v3.sub(this.portT, rC0), [0, 0, 1]), euler("zyx", [N(1.5 * deg), N(1.5 * deg), N(1.5 * deg)]));
    this.x = [...v3.sub(v3.add(rC0, mulVec(this.R_c, PORT_CHASER)), this.portT), 0, 0, 0];   // truth: port to port, LVLH

    // navigation initialisation: a coarse hand-over estimate (e.g. from far-range navigation)
    this.nav = new RelNavFilter(this.n, [...this.x.slice(0, 3).map((xi) => xi + N(1.0)), 0, 0, 0], 2.0, 0.05);
    this.axisEst = v3.unit(v3.add(this.axisL, [N(0.03), N(0.03), N(0.03)]));
    this.R_ct_prior = null;
    this.guidance = new Guidance();

    this.t = 0; this.tLastFix = -1e9; this.tNextVision = 0; this.dv = 0; this.frames = 0;
    this.docked = null; this.done = false;
    this.fixErrors = []; this.telemetry = []; this.lastFrame = null;
    this.N = N;
  }

  ownState() {                                             // GNSS + star tracker: chaser position and attitude
    return { r_c: v3.sub(v3.add(this.portT, this.x.slice(0, 3)), mulVec(this.R_c, PORT_CHASER)), R_c: this.R_c };
  }

  /** One control step (dt seconds of mission time). Returns the telemetry row. */
  step() {
    if (this.done) return null;
    const { dt, visionPeriod, finalVisionPeriod, dropout, misfire } = this.opts;
    const { cam, target, nav, guidance } = this;
    const t = this.t;
    const { r_c, R_c } = this.ownState();
    const xTrue = this.x.slice(), axisTrue = this.axisL;
    let fix = "", measErr = NaN, frame = null;

    // ---------- sensing: a rendered camera frame ----------
    if (t >= this.tNextVision) {
      const closeBlind = v3.norm(nav.x.slice(0, 3)) < 3.0 && t - this.tLastFix > visionPeriod + 0.5;
      this.tNextVision = t + (closeBlind ? finalVisionPeriod : visionPeriod);
      const inDropout = Boolean(dropout) && dropout[0] <= t && t < dropout[1];
      const R_cam = mul(R_c, cam.R_body_cam);              // OpenCV camera axes in LVLH
      const camPos = v3.add(r_c, mulVec(R_c, cam.offsetBody));
      frame = { ...this.camera(camPos, R_cam), t, dropout: inDropout };
      this.frames++;
      const priorAxisCam = mulVec(transpose(cam.R_body_cam), mulVec(transpose(R_c), this.axisEst));
      const pose = inDropout || !frame.corners ? null : poseFromCorners(frame.corners, cam, target, priorAxisCam, this.R_ct_prior);
      frame.pose = pose;
      if (pose) {
        const portTcam = v3.add(mulVec(pose.Rct, target.portTarget), pose.tct);
        const portCw = v3.add(r_c, mulVec(R_c, PORT_CHASER));
        const portTw = v3.add(r_c, mulVec(R_c, v3.add(cam.offsetBody, mulVec(cam.R_body_cam, portTcam))));
        const axisW = mulVec(R_c, mulVec(cam.R_body_cam, mulVec(pose.Rct, target.portAxisTarget)));
        const z = v3.sub(portCw, portTw);
        const rngM = v3.norm(z);
        const sigma = rngM < 10 ? 0.01 + 0.002 * rngM : 0.01 + 0.0015 * rngM ** 2;   // measured on MDS frames
        if (nav.updatePosition(z, sigma)) {
          this.tLastFix = t; fix = pose.source;
          if (!pose.source.includes("position only")) {
            this.axisEst = v3.unit(v3.add(v3.scale(this.axisEst, 0.6), v3.scale(axisW, 0.4)));
            this.R_ct_prior = pose.Rct;
          }
        }
        measErr = v3.norm(v3.sub(z, xTrue.slice(0, 3)));
        this.fixErrors.push([t, rngM, measErr, pose.source]);
        frame.z = z; frame.measErr = measErr;
      }
      this.lastFrame = frame;
    }

    // ---------- scoring ----------
    const navErr = v3.norm(v3.sub(nav.x.slice(0, 3), xTrue.slice(0, 3)));
    const axisErr = Math.acos(Math.max(-1, Math.min(1, v3.dot(this.axisEst, axisTrue)))) / deg;
    const row = [Math.round(t * 10) / 10, guidance.phase, r4(v3.norm(xTrue.slice(0, 3))), ...nav.x.slice(0, 3).map(r4),
      ...xTrue.map(r4), r4(navErr), r4(nav.posSigma), measErr, Math.round(axisErr * 1e3) / 1e3, fix, r4(this.dv)];
    this.telemetry.push(row);
    const out = { row, frame, navErr, axisErr, xTrue, navX: nav.x.slice() };

    // ---------- contact ----------
    const along = v3.dot(xTrue.slice(0, 3), axisTrue);
    if (along < 0) {
      const lat = v3.norm(v3.sub(xTrue.slice(0, 3), v3.scale(axisTrue, along)));
      const spd = v3.norm(xTrue.slice(3));
      this.docked = { t, ok: lat < 0.1 && spd < 0.06, lateral_miss_m: lat, contact_speed_mps: spd };
      this.done = true;
      return out;
    }

    // ---------- guidance & actuation ----------
    const accel = guidance.command(t, nav.x, this.axisEst, this.n, t - this.tLastFix, nav.posSigma);
    const qCmd = xAligned(v3.scale(this.axisEst, -1), [0, 0, 1]);   // +X (camera, port) toward the target, roll to orbit normal
    let aTrue = accel.map((a) => a * 1.02 + this.N(2e-5));
    if (misfire && misfire[0] <= t && t < misfire[0] + 1) aTrue = v3.add(aTrue, misfire[1]);
    this.x = cwPropagate(this.n, this.x, aTrue, dt);
    this.R_c = mul(rotvec([this.N(0.1 * deg), this.N(0.1 * deg), this.N(0.1 * deg)]), qCmd);
    nav.predict(dt, accel);
    this.dv += v3.norm(accel) * dt;
    this.t += dt;
    if (this.t >= this.opts.maxTime) this.done = true;
    return out;
  }

  summary() {
    const errs = this.fixErrors.map((f) => f[2]).sort((a, b) => a - b);
    const mean = errs.reduce((s, e) => s + e, 0) / (errs.length || 1);
    const p95 = errs.length ? errs[Math.min(errs.length - 1, Math.ceil(0.95 * (errs.length - 1)))] : NaN;
    return {
      physics: "cw", docked: this.docked, mission_time_s: this.t, delta_v_mps: this.dv, events: this.guidance.events,
      frames: this.frames, vision_fixes: this.fixErrors.length,
      measurement_error_m: { mean, p95, max: errs.length ? errs[errs.length - 1] : NaN },
    };
  }

  csv() {
    const fmt = (v) => (typeof v === "number" ? (Number.isNaN(v) ? "nan" : String(v)) : v);
    return [TELEMETRY_COLUMNS.join(","), ...this.telemetry.map((r) => r.map(fmt).join(","))].join("\n") + "\n";
  }
}
