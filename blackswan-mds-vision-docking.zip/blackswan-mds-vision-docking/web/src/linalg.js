// Small dense linear algebra for 3x3 / 6x6 problems (row-major arrays of arrays). No dependencies.

export const zeros = (r, c) => Array.from({ length: r }, () => new Array(c).fill(0));
export const eye = (n) => zeros(n, n).map((row, i) => { row[i] = 1; return row; });
export const clone = (A) => A.map((r) => r.slice());

export function mul(A, B) {
  const n = A.length, m = B[0].length, k = B.length;
  const C = zeros(n, m);
  for (let i = 0; i < n; i++)
    for (let p = 0; p < k; p++) {
      const a = A[i][p];
      if (a === 0) continue;
      for (let j = 0; j < m; j++) C[i][j] += a * B[p][j];
    }
  return C;
}

export const mulVec = (A, v) => A.map((row) => row.reduce((s, a, j) => s + a * v[j], 0));
export const transpose = (A) => A[0].map((_, j) => A.map((row) => row[j]));
export const add = (A, B) => A.map((row, i) => row.map((a, j) => a + B[i][j]));
export const sub = (A, B) => A.map((row, i) => row.map((a, j) => a - B[i][j]));
export const scale = (A, s) => A.map((row) => row.map((a) => a * s));

/** Gauss-Jordan inverse with partial pivoting. */
export function inv(A) {
  const n = A.length;
  const M = A.map((row, i) => [...row, ...eye(n)[i]]);
  for (let c = 0; c < n; c++) {
    let p = c;
    for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[p][c])) p = r;
    if (Math.abs(M[p][c]) < 1e-14) throw new Error("singular matrix");
    [M[c], M[p]] = [M[p], M[c]];
    const d = M[c][c];
    for (let j = 0; j < 2 * n; j++) M[c][j] /= d;
    for (let r = 0; r < n; r++) {
      if (r === c) continue;
      const f = M[r][c];
      if (f !== 0) for (let j = 0; j < 2 * n; j++) M[r][j] -= f * M[c][j];
    }
  }
  return M.map((row) => row.slice(n));
}

/** Solve the least-squares problem A x = b via the normal equations (small, well-conditioned systems). */
export function lstsq(A, b) {
  const At = transpose(A);
  return mulVec(inv(mul(At, A)), mulVec(At, b));
}

// --- 3-vectors ---
export const v3 = {
  add: (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]],
  sub: (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]],
  scale: (a, s) => [a[0] * s, a[1] * s, a[2] * s],
  dot: (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2],
  cross: (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]],
  norm: (a) => Math.hypot(a[0], a[1], a[2]),
  unit: (a) => { const n = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / n, a[1] / n, a[2] / n]; },
};

// --- rotations (3x3 matrices) ---
/** Rotation matrix from a rotation vector (axis * angle), Rodrigues' formula. */
export function rotvec(w) {
  const th = v3.norm(w);
  if (th < 1e-12) return [[1, -w[2], w[1]], [w[2], 1, -w[0]], [-w[1], w[0], 1]];
  const [x, y, z] = v3.scale(w, 1 / th), c = Math.cos(th), s = Math.sin(th), C = 1 - c;
  return [
    [c + x * x * C, x * y * C - z * s, x * z * C + y * s],
    [y * x * C + z * s, c + y * y * C, y * z * C - x * s],
    [z * x * C - y * s, z * y * C + x * s, c + z * z * C],
  ];
}

/** Angle (radians) of the rotation taking A to B. */
export function rotAngle(A, B) {
  const R = mul(transpose(A), B);
  const tr = R[0][0] + R[1][1] + R[2][2];
  return Math.acos(Math.max(-1, Math.min(1, (tr - 1) / 2)));
}

/** Nearest rotation matrix to M (orthonormalise via symmetric Gram-Schmidt iterations). */
export function orthonormalize(M) {
  let R = clone(M);
  for (let k = 0; k < 20; k++) {
    const Rit = inv(transpose(R));
    R = scale(add(R, Rit), 0.5);
  }
  return R;
}

/** Gaussian random number (Box-Muller) from a uniform RNG in [0, 1). */
export function gauss(rng = Math.random) {
  let u = 0;
  while (u === 0) u = rng();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * rng());
}

/** Small seeded RNG (mulberry32) so Monte Carlo runs are reproducible. */
export function seeded(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// --- additions for the MDS port ---
export const outer = (a, b) => a.map((x) => b.map((y) => x * y));
export const diag = (v) => v.map((x, i) => v.map((_, j) => (i === j ? x : 0)));
export const vadd = (a, b) => a.map((x, i) => x + b[i]);
export const vsub = (a, b) => a.map((x, i) => x - b[i]);
export const vscale = (a, s) => a.map((x) => x * s);
export const vdot = (a, b) => a.reduce((s, x, i) => s + x * b[i], 0);
export const vnorm = (a) => Math.sqrt(vdot(a, a));
/** Columns -> matrix. */
export const fromColumns = (...cols) => [0, 1, 2].map((i) => cols.map((c) => c[i]));
export const column = (A, j) => A.map((r) => r[j]);
/** Solve A x = b (small systems). */
export const solve = (A, b) => mulVec(inv(A), b);
/** Rotation vector (axis * angle) of a rotation matrix. */
export function logRot(R) {
  const tr = R[0][0] + R[1][1] + R[2][2];
  const th = Math.acos(Math.max(-1, Math.min(1, (tr - 1) / 2)));
  const w = [R[2][1] - R[1][2], R[0][2] - R[2][0], R[1][0] - R[0][1]];
  if (th < 1e-9) return v3.scale(w, 0.5);
  if (Math.PI - th < 1e-6) {                       // near 180 deg: axis from the symmetric part
    const k = [0, 1, 2].reduce((m, i) => (R[i][i] > R[m][m] ? i : m), 0);
    const a = [0, 1, 2].map((i) => (R[i][k] + R[k][i]) / 2 + (i === k ? -(tr - 1) / 2 : 0));
    return v3.scale(v3.unit(a), th);
  }
  return v3.scale(w, th / (2 * Math.sin(th)));
}
/** Rotation from Euler angles (radians), extrinsic sequence like scipy's lowercase Rotation.from_euler("zyx", ...). */
export function euler(seq, angles) {
  const axes = { x: [1, 0, 0], y: [0, 1, 0], z: [0, 0, 1] };
  let R = eye(3);
  [...seq].forEach((ax, i) => { R = mul(rotvec(v3.scale(axes[ax], angles[i])), R); });
  return R;
}
