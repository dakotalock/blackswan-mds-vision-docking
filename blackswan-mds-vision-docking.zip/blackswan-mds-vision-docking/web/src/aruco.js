// ArUco marker detection on raw pixels, for the one marker the target carries (DICT_5X5_50, id 3).
// Same job as OpenCV's ArucoDetector + cornerSubPix in util_vision_nav.FiducialTarget.detect():
//   1. adaptive threshold (a pixel is "dark" if it is darker than its neighbourhood) at a few window sizes;
//   2. connected dark regions -> convex hull -> the four corners of a quadrilateral;
//   3. read the 7x7 cell grid through the quad's perspective (homography): a black border and the 5x5 id bits;
//   4. sub-pixel corners: fit a straight line to each black/white edge and intersect neighbouring edges.
// Returns the 4 corners in ArUco order (top-left, top-right, bottom-right, bottom-left of the marker), or null.

// DICT_5X5_50 id 3 (from cv2.aruco.generateImageMarker; 1 = white), inner 5x5 bits, row by row
export const MARKER_BITS = [
  [1, 0, 0, 0, 0],
  [0, 0, 1, 1, 1],
  [0, 0, 1, 0, 1],
  [0, 1, 1, 1, 1],
  [1, 0, 1, 1, 1],
];

/** RGBA (top row first) -> grey levels, OpenCV's BGR2GRAY weights. */
export function toGray(rgba, w, h) {
  const g = new Float32Array(w * h);
  for (let i = 0, j = 0; i < g.length; i++, j += 4) g[i] = 0.299 * rgba[j] + 0.587 * rgba[j + 1] + 0.114 * rgba[j + 2];
  return g;
}

function bilinear(g, w, h, x, y) {
  if (x < 0 || y < 0 || x > w - 1.001 || y > h - 1.001) return NaN;
  const x0 = Math.floor(x), y0 = Math.floor(y), fx = x - x0, fy = y - y0, i = y0 * w + x0;
  return (g[i] * (1 - fx) + g[i + 1] * fx) * (1 - fy) + (g[i + w] * (1 - fx) + g[i + w + 1] * fx) * fy;
}

function integral(g, w, h) {
  const I = new Float64Array((w + 1) * (h + 1));
  for (let y = 0; y < h; y++) {
    let row = 0;
    for (let x = 0; x < w; x++) { row += g[y * w + x]; I[(y + 1) * (w + 1) + x + 1] = I[y * (w + 1) + x + 1] + row; }
  }
  return I;
}

function adaptiveDark(g, I, w, h, win, C) {
  const out = new Uint8Array(w * h), r = win >> 1;
  for (let y = 0; y < h; y++) {
    const y0 = Math.max(0, y - r), y1 = Math.min(h, y + r + 1);
    for (let x = 0; x < w; x++) {
      const x0 = Math.max(0, x - r), x1 = Math.min(w, x + r + 1);
      const s = I[y1 * (w + 1) + x1] - I[y0 * (w + 1) + x1] - I[y1 * (w + 1) + x0] + I[y0 * (w + 1) + x0];
      out[y * w + x] = g[y * w + x] < s / ((x1 - x0) * (y1 - y0)) - C ? 1 : 0;
    }
  }
  return out;
}

/** Connected components (8-neighbour) of a binary image; returns each component's boundary pixels. */
function components(bin, w, h, minPix) {
  const label = new Int32Array(w * h), comps = [], stack = [];
  let next = 1;
  for (let s = 0; s < bin.length; s++) {
    if (!bin[s] || label[s]) continue;
    const boundary = [];
    let count = 0, touches = false;
    label[s] = next; stack.push(s);
    while (stack.length) {
      const p = stack.pop(), x = p % w, y = (p - x) / w;
      count++;
      if (x === 0 || y === 0 || x === w - 1 || y === h - 1) touches = true;
      let edge = false;
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        if (!dx && !dy) continue;
        const X = x + dx, Y = y + dy;
        if (X < 0 || Y < 0 || X >= w || Y >= h) { edge = true; continue; }
        const q = Y * w + X;
        if (!bin[q]) { edge = true; continue; }
        if (!label[q]) { label[q] = next; stack.push(q); }
      }
      if (edge) boundary.push([x, y]);
    }
    next++;
    if (count >= minPix && !touches) comps.push(boundary);
  }
  return comps;
}

function convexHull(pts) {
  const p = pts.slice().sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  const cross = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
  const lower = [], upper = [];
  for (const q of p) { while (lower.length >= 2 && cross(lower[lower.length - 2], lower[lower.length - 1], q) <= 0) lower.pop(); lower.push(q); }
  for (const q of p.reverse()) { while (upper.length >= 2 && cross(upper[upper.length - 2], upper[upper.length - 1], q) <= 0) upper.pop(); upper.push(q); }
  return lower.slice(0, -1).concat(upper.slice(0, -1));
}

const polyArea = (P) => Math.abs(P.reduce((s, p, i) => { const q = P[(i + 1) % P.length]; return s + p[0] * q[1] - q[0] * p[1]; }, 0)) / 2;

/** Four corners of a roughly quadrilateral hull: farthest pair, then the farthest point on each side of it. */
function quadFromHull(H) {
  const cx = H.reduce((s, p) => s + p[0], 0) / H.length, cy = H.reduce((s, p) => s + p[1], 0) / H.length;
  const far = (from) => H.reduce((b, p) => ((p[0] - from[0]) ** 2 + (p[1] - from[1]) ** 2 > (b[0] - from[0]) ** 2 + (b[1] - from[1]) ** 2 ? p : b), H[0]);
  const a = far([cx, cy]), c = far(a);
  const side = (p) => (c[0] - a[0]) * (p[1] - a[1]) - (c[1] - a[1]) * (p[0] - a[0]);
  let b = null, d = null;
  for (const p of H) {
    const s = side(p);
    if (s > 0 && (!b || s > side(b))) b = p;
    if (s < 0 && (!d || s < side(d))) d = p;
  }
  if (!b || !d) return null;
  // clockwise on screen (y down): sort by angle around the centre
  const q = [a, b, c, d], mx = (a[0] + b[0] + c[0] + d[0]) / 4, my = (a[1] + b[1] + c[1] + d[1]) / 4;
  return q.sort((u, v) => Math.atan2(u[1] - my, u[0] - mx) - Math.atan2(v[1] - my, v[0] - mx)).map((p) => [p[0], p[1]]);
}

/** Homography mapping the unit-cell square (0,0),(7,0),(7,7),(0,7) onto 4 image points. */
function squareToQuad(q) {
  const src = [[0, 0], [7, 0], [7, 7], [0, 7]], A = [], b = [];
  for (let i = 0; i < 4; i++) {
    const [X, Y] = src[i], [u, v] = q[i];
    A.push([X, Y, 1, 0, 0, 0, -u * X, -u * Y]); b.push(u);
    A.push([0, 0, 0, X, Y, 1, -v * X, -v * Y]); b.push(v);
  }
  const h = gaussSolve(A, b);
  return h && ((X, Y) => { const z = h[6] * X + h[7] * Y + 1; return [(h[0] * X + h[1] * Y + h[2]) / z, (h[3] * X + h[4] * Y + h[5]) / z]; });
}

function gaussSolve(A, b) {
  const n = b.length, M = A.map((r, i) => [...r, b[i]]);
  for (let c = 0; c < n; c++) {
    let p = c;
    for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[p][c])) p = r;
    if (Math.abs(M[p][c]) < 1e-12) return null;
    [M[c], M[p]] = [M[p], M[c]];
    for (let r = 0; r < n; r++) if (r !== c) { const f = M[r][c] / M[c][c]; for (let j = c; j <= n; j++) M[r][j] -= f * M[c][j]; }
  }
  return M.map((r, i) => r[n] / r[i]);
}

/** Read the 7x7 cells; returns the id bits if the border is black, else null. */
function readCells(g, w, h, map) {
  const cells = [];
  for (let i = 0; i < 7; i++) for (let j = 0; j < 7; j++) {
    let s = 0, n = 0;
    for (let a = 0; a < 3; a++) for (let b = 0; b < 3; b++) {
      const [x, y] = map(j + 0.3 + 0.2 * b, i + 0.3 + 0.2 * a);
      const v = bilinear(g, w, h, x, y);
      if (!Number.isNaN(v)) { s += v; n++; }
    }
    if (!n) return null;
    cells.push(s / n);
  }
  const lo = Math.min(...cells), hi = Math.max(...cells);
  if (hi - lo < 30) return null;
  const thr = (lo + hi) / 2;
  for (let i = 0; i < 7; i++) for (let j = 0; j < 7; j++)
    if ((i === 0 || j === 0 || i === 6 || j === 6) && cells[i * 7 + j] > thr) return null;
  return [1, 2, 3, 4, 5].map((i) => [1, 2, 3, 4, 5].map((j) => (cells[i * 7 + j] > thr ? 1 : 0)));
}

/** Total-least-squares line through points: centroid and principal direction. */
function fitLine(pts) {
  const mx = pts.reduce((s, p) => s + p[0], 0) / pts.length, my = pts.reduce((s, p) => s + p[1], 0) / pts.length;
  let sxx = 0, sxy = 0, syy = 0;
  for (const [x, y] of pts) { sxx += (x - mx) ** 2; sxy += (x - mx) * (y - my); syy += (y - my) ** 2; }
  const th = 0.5 * Math.atan2(2 * sxy, sxx - syy);
  return { p: [mx, my], d: [Math.cos(th), Math.sin(th)] };
}

/** Sub-pixel corners: a line fitted to each edge's strongest gradient, neighbouring lines intersected;
 *  a second pass starts from the first pass's corners. */
function refineCorners(g, w, h, q) {
  return refineOnce(g, w, h, refineOnce(g, w, h, q));
}

function refineOnce(g, w, h, q) {
  const side = q.reduce((s, p, i) => s + Math.hypot(p[0] - q[(i + 1) % 4][0], p[1] - q[(i + 1) % 4][1]), 0) / 4;
  const reach = Math.max(1, Math.min(3, (side / 7) * 0.6));
  const lines = [];
  for (let e = 0; e < 4; e++) {
    const A = q[e], B = q[(e + 1) % 4];
    const len = Math.hypot(B[0] - A[0], B[1] - A[1]), d = [(B[0] - A[0]) / len, (B[1] - A[1]) / len], nrm = [-d[1], d[0]];
    const pts = [];
    const nSamp = Math.max(6, Math.min(40, Math.floor(len / 2)));
    for (let k = 0; k < nSamp; k++) {
      const s = 0.12 + (0.76 * k) / (nSamp - 1);
      const P = [A[0] + s * (B[0] - A[0]), A[1] + s * (B[1] - A[1])];
      let best = -1, bestO = 0;
      const prof = [];
      for (let o = -reach - 0.5; o <= reach + 0.5 + 1e-9; o += 0.25) prof.push([o, bilinear(g, w, h, P[0] + o * nrm[0], P[1] + o * nrm[1])]);
      const grad = [];
      for (let i = 1; i < prof.length - 1; i++) grad.push([prof[i][0], Math.abs(prof[i + 1][1] - prof[i - 1][1])]);
      grad.forEach(([o, gv], i) => { if (Math.abs(o) <= reach && gv > best) { best = gv; bestO = i; } });
      if (!(best > 8)) continue;
      // the edge is where the brightness crosses halfway between the dark and bright sides (exact for a straight
      // edge under pixel averaging; the gradient peak alone is ambiguous when the edge lines up with the pixel grid)
      const vals = prof.map((p) => p[1]).filter((x) => !Number.isNaN(x));
      if (vals.length < prof.length) continue;
      const mid = (Math.min(...vals) + Math.max(...vals)) / 2;
      let o = null;
      for (let dI = 0; dI < prof.length && o === null; dI++) {
        for (const i of [bestO + 1 + dI, bestO + 1 - dI]) {
          if (i < 1 || i >= prof.length) continue;
          const [oa, va] = prof[i - 1], [ob, vb] = prof[i];
          if ((va - mid) * (vb - mid) <= 0 && va !== vb) { o = oa + ((mid - va) / (vb - va)) * (ob - oa); break; }
        }
      }
      if (o === null || Math.abs(o) > reach + 0.5) continue;
      pts.push([P[0] + o * nrm[0], P[1] + o * nrm[1]]);
    }
    if (pts.length < 4) return q;
    let line = fitLine(pts);
    for (let pass = 0; pass < 2; pass++) {                                   // drop outliers, refit
      const dist = pts.map(([x, y]) => Math.abs((x - line.p[0]) * line.d[1] - (y - line.p[1]) * line.d[0]));
      const med = dist.slice().sort((u, v) => u - v)[dist.length >> 1];
      const keep = pts.filter((_, i) => dist[i] <= Math.max(0.15, 3 * med));
      if (keep.length >= 4) line = fitLine(keep);
    }
    lines.push(line);
  }
  const out = [];
  for (let k = 0; k < 4; k++) {
    const L1 = lines[(k + 3) % 4], L2 = lines[k];                             // edges meeting at corner k
    const det = L1.d[0] * -L2.d[1] + L2.d[0] * L1.d[1];
    if (Math.abs(det) < 1e-9) return q;
    const rx = L2.p[0] - L1.p[0], ry = L2.p[1] - L1.p[1];
    const s = (rx * -L2.d[1] + L2.d[0] * ry) / det;
    const c = [L1.p[0] + s * L1.d[0], L1.p[1] + s * L1.d[1]];
    if (Math.hypot(c[0] - q[k][0], c[1] - q[k][1]) > 4) return q;             // refinement went astray: keep coarse
    out.push(c);
  }
  return out;
}

const hamming = (A, B) => A.reduce((s, row, i) => s + row.reduce((t, v, j) => t + (v !== B[i][j]), 0), 0);

/** Find the marker; returns { corners, candidates } with corners in ArUco order, or null. */
export function detectMarker(gray, w, h, bits = MARKER_BITS) {
  const I = integral(gray, w, h);
  for (const win of [15, 41, 101]) {
    const bin = adaptiveDark(gray, I, w, h, win, 7);
    for (const comp of components(bin, w, h, 30)) {
      const hull = convexHull(comp);
      if (hull.length < 4) continue;
      const q = quadFromHull(hull);
      if (!q) continue;
      const minSide = Math.min(...q.map((p, i) => Math.hypot(p[0] - q[(i + 1) % 4][0], p[1] - q[(i + 1) % 4][1])));
      if (minSide < 10 || polyArea(q) < 0.85 * polyArea(hull)) continue;
      for (let r = 0; r < 4; r++) {
        const qr = [0, 1, 2, 3].map((k) => q[(k + r) % 4]);
        const map = squareToQuad(qr);
        const read = map && readCells(gray, w, h, map);
        if (read && hamming(read, bits) <= 1) return { corners: refineCorners(gray, w, h, qr), window: win };
      }
    }
  }
  return null;
}

