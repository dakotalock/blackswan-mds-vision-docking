// three.js scene: a GEOSAT-like target (look-alike geometry, built here) carrying the ArUco marker exactly where the
// calibration puts it, a docking chaser, and the chaser's camera, rendered off-screen at 640x480 for the flight software.
// World frame = the target's LVLH frame (x radial, y along-track, z orbit normal), metres.

import * as THREE from "three";
import { MARKER_BITS } from "./aruco.js";
import { R_LT, PORT_CHASER } from "./mission.js";

const mat4 = (R, p = [0, 0, 0]) => new THREE.Matrix4().set(
  R[0][0], R[0][1], R[0][2], p[0], R[1][0], R[1][1], R[1][2], p[1], R[2][0], R[2][1], R[2][2], p[2], 0, 0, 0, 1);

function canvasTexture(w, h, draw) {
  const c = document.createElement("canvas"); c.width = w; c.height = h;
  draw(c.getContext("2d"), w, h);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
  return t;
}

function goldFoil() {
  return canvasTexture(512, 512, (g, w, h) => {
    g.fillStyle = "#9a7428"; g.fillRect(0, 0, w, h);
    for (let i = 0; i < 900; i++) {                         // crinkled multilayer insulation
      const x = Math.random() * w, y = Math.random() * h, r = 6 + Math.random() * 30;
      const grad = g.createRadialGradient(x, y, 0, x, y, r);
      const l = 90 + Math.random() * 110;
      grad.addColorStop(0, `rgba(${l + 60},${l + 25},${l - 40},0.35)`); grad.addColorStop(1, "rgba(0,0,0,0)");
      g.fillStyle = grad; g.fillRect(x - r, y - r, 2 * r, 2 * r);
    }
  });
}

function markerTexture() {                                   // 7x7 cells + a half-cell white quiet zone
  return canvasTexture(8 * 64, 8 * 64, (g) => {
    g.fillStyle = "#f2f2f2"; g.fillRect(0, 0, 512, 512);
    const grid = [[0, 0, 0, 0, 0, 0, 0], ...MARKER_BITS.map((r) => [0, ...r, 0]), [0, 0, 0, 0, 0, 0, 0]];
    grid.forEach((row, i) => row.forEach((b, j) => { g.fillStyle = b ? "#f2f2f2" : "#0b0b0b"; g.fillRect(32 + 64 * j, 32 + 64 * i, 64, 64); }));
  });
}

function panelTexture() {
  return canvasTexture(256, 1024, (g, w, h) => {
    g.fillStyle = "#101a33"; g.fillRect(0, 0, w, h);
    g.strokeStyle = "#8a93a8"; g.lineWidth = 2;
    for (let x = 0; x <= w; x += 32) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, h); g.stroke(); }
    for (let y = 0; y <= h; y += 32) { g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke(); }
  });
}

/** The target, in its body frame (docking face +Z, port at [0, 0, 3.18]). */
function buildTarget(cal) {
  const T = new THREE.Group();
  const foil = new THREE.MeshStandardMaterial({ map: goldFoil(), metalness: 0.55, roughness: 0.45 });
  const grey = new THREE.MeshStandardMaterial({ color: 0x9aa0a8, metalness: 0.4, roughness: 0.5 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x3a3f47, metalness: 0.5, roughness: 0.6 });
  const cream = new THREE.MeshStandardMaterial({ color: 0xd8d2c0, roughness: 0.8, side: THREE.DoubleSide });
  const faceZ = 2.575;
  const bus = new THREE.Mesh(new THREE.BoxGeometry(4.2, 4.2, faceZ + 1.6), foil);
  bus.position.z = (faceZ - 1.6) / 2; T.add(bus);
  // docking face details
  const disk = new THREE.Mesh(new THREE.CylinderGeometry(0.62, 0.62, 0.06, 48), grey);
  disk.rotation.x = Math.PI / 2; disk.position.set(1.15, 1.15, faceZ + 0.03); T.add(disk);
  const plate = new THREE.Mesh(new THREE.BoxGeometry(1.0, 1.0, 0.05), grey);
  plate.position.set(-1.15, 1.15, faceZ + 0.025); T.add(plate);
  const well = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.35, 40, 1, true), dark);
  well.rotation.x = Math.PI / 2; well.position.set(1.15, -1.15, faceZ + 0.17); T.add(well);
  // docking port: octagonal plate, tube, capture ring at z = 3.18
  const oct = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 0.06, 8), dark);
  oct.rotation.x = Math.PI / 2; oct.position.z = faceZ + 0.03; T.add(oct);
  const tube = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.3, 3.18 - faceZ, 32), grey);
  tube.rotation.x = Math.PI / 2; tube.position.z = (3.18 + faceZ) / 2; T.add(tube);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.3, 0.04, 12, 48), grey);
  ring.position.z = 3.18; T.add(ring);
  // the ArUco marker, exactly where the calibration says it is
  const s = cal.marker_side_m;
  const marker = new THREE.Mesh(new THREE.PlaneGeometry((s * 8) / 7, (s * 8) / 7),
    new THREE.MeshStandardMaterial({ map: markerTexture(), roughness: 0.9, metalness: 0 }));
  marker.matrixAutoUpdate = false;
  marker.matrix.copy(mat4(cal.R_target_marker, cal.marker_center_target));
  T.add(marker);
  // solar panels along +-X, antennas on +-Y
  const pmat = new THREE.MeshStandardMaterial({ map: panelTexture(), metalness: 0.3, roughness: 0.4, side: THREE.DoubleSide });
  for (const sgn of [-1, 1]) {
    const boom = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 1.2, 8), grey);
    boom.rotation.z = Math.PI / 2; boom.position.set(sgn * 2.7, 0, 0); T.add(boom);
    const panel = new THREE.Mesh(new THREE.BoxGeometry(13, 2.6, 0.05), pmat);
    panel.position.set(sgn * 9.8, 0, 0); T.add(panel);
    const dish = new THREE.Mesh(new THREE.SphereGeometry(2.1, 40, 16, 0, Math.PI * 2, 0, 0.55), cream);
    dish.rotation.x = sgn * Math.PI / 2; dish.position.set(0, sgn * 4.0, 0.2); T.add(dish);
  }
  return T;
}

/** The chaser, in its body frame (+X: camera boresight and docking port at [2.12, 0, 0]). */
function buildChaser() {
  const C = new THREE.Group();
  const white = new THREE.MeshStandardMaterial({ color: 0xe6e8ec, metalness: 0.2, roughness: 0.6 });
  const grey = new THREE.MeshStandardMaterial({ color: 0x8c939c, metalness: 0.5, roughness: 0.4 });
  const body = new THREE.Mesh(new THREE.BoxGeometry(3.0, 2.0, 2.0), white);
  body.position.x = -0.3; C.add(body);
  const port = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.34, PORT_CHASER[0] - 1.2, 24), grey);
  port.rotation.z = -Math.PI / 2; port.position.x = (PORT_CHASER[0] + 1.2) / 2; C.add(port);
  const pmat = new THREE.MeshStandardMaterial({ map: panelTexture(), metalness: 0.3, roughness: 0.4, side: THREE.DoubleSide });
  for (const sgn of [-1, 1]) {
    const p = new THREE.Mesh(new THREE.BoxGeometry(1.6, 4.0, 0.04), pmat);
    p.position.set(-0.5, sgn * 3.1, 0); C.add(p);
  }
  return C;
}

export class DockingScene {
  constructor(viewCanvas, cal, camModel) {
    this.cal = cal; this.camModel = camModel;
    this.renderer = new THREE.WebGLRenderer({ canvas: viewCanvas, antialias: true, logarithmicDepthBuffer: true, preserveDrawingBuffer: false });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x02030a);
    this.scene.add(new THREE.AmbientLight(0xffffff, 0.35));
    const sun = new THREE.DirectionalLight(0xfff4e0, 2.6);
    sun.position.set(0.5, -1.0, 0.45);                       // sunlight from behind the chaser, a little above
    this.scene.add(sun);
    this.scene.add(new THREE.HemisphereLight(0x8fb4ff, 0x201a10, 0.25));

    const stars = new THREE.BufferGeometry(), pts = [];
    for (let i = 0; i < 2500; i++) {
      const v = new THREE.Vector3().randomDirection().multiplyScalar(3000);
      pts.push(v.x, v.y, v.z);
    }
    stars.setAttribute("position", new THREE.Float32BufferAttribute(pts, 3));
    this.stars = new THREE.Points(stars, new THREE.PointsMaterial({ color: 0xffffff, size: 1.3, sizeAttenuation: false }));
    this.scene.add(this.stars);

    this.target = buildTarget(cal);
    this.target.matrixAutoUpdate = false;
    this.target.matrix.copy(mat4(R_LT));
    this.scene.add(this.target);
    this.chaser = buildChaser();
    this.chaser.matrixAutoUpdate = false;
    this.scene.add(this.chaser);

    // guidance geometry: approach corridor (10 deg inside 15 m) and the 15 m keep-out sphere around the port
    const port = new THREE.Vector3(0, -3.18, 0);
    const cone = new THREE.Mesh(new THREE.ConeGeometry(15 * Math.tan((10 * Math.PI) / 180), 15, 48, 1, true),
      new THREE.MeshBasicMaterial({ color: 0x34d399, transparent: true, opacity: 0.08, side: THREE.DoubleSide, depthWrite: false }));
    cone.position.copy(port).add(new THREE.Vector3(0, -7.5, 0));      // apex at the port, opening along -y (the docking axis)
    this.overlay = new THREE.Group();
    this.overlay.add(cone);
    const ringMat = new THREE.LineBasicMaterial({ color: 0xf87171, transparent: true, opacity: 0.35 });
    for (const [ax, ang] of [["x", 0], ["y", Math.PI / 2], ["z", Math.PI / 2]]) {   // keep-out sphere as three great circles
      const pts = []; for (let i = 0; i <= 96; i++) { const a = (i / 96) * 2 * Math.PI; pts.push(new THREE.Vector3(15 * Math.cos(a), 15 * Math.sin(a), 0)); }
      const c = new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), ringMat);
      c.rotation[ax] = ang; c.position.copy(port); this.overlay.add(c);
    }
    this.truePath = this.makeLine(0x38bdf8); this.estPath = this.makeLine(0xfbbf24);
    this.scene.add(this.overlay);

    // the chaser's camera (OpenCV intrinsics -> three.js projection), rendered off-screen
    const K = camModel.K, W = camModel.width, H = camModel.height;
    this.flightCam = new THREE.PerspectiveCamera((2 * Math.atan(H / 2 / K[1][1]) * 180) / Math.PI, W / H, 0.2, 5000);
    this.flightCam.matrixAutoUpdate = false;
    this.target_rt = new THREE.WebGLRenderTarget(W, H, { samples: 4, colorSpace: THREE.SRGBColorSpace });
    this.pixels = new Uint8Array(W * H * 4);
    this.rgba = new Uint8ClampedArray(W * H * 4);

    this.viewCam = new THREE.PerspectiveCamera(45, 1, 0.1, 20000);
    this.viewCam.up.set(1, 0, 0);                               // radial is "up" in the external view
    this.viewCam.position.set(9, -24, 16);
    this.viewCam.lookAt(0, -9, 0);
  }

  makeLine(color) {
    const geom = new THREE.BufferGeometry();
    geom.setAttribute("position", new THREE.BufferAttribute(new Float32Array(3 * 4000), 3));
    geom.setDrawRange(0, 0);
    const line = new THREE.Line(geom, new THREE.LineBasicMaterial({ color }));
    this.overlay.add(line);
    return line;
  }

  resetPaths() { this.truePath.geometry.setDrawRange(0, 0); this.estPath.geometry.setDrawRange(0, 0); }

  pushPath(line, p) {
    const g = line.geometry, n = g.drawRange.count;
    if (n >= 4000) return;
    g.attributes.position.setXYZ(n, p[0], p[1], p[2]);
    g.attributes.position.needsUpdate = true;
    g.setDrawRange(0, n + 1);
  }

  setChaser(r_c, R_c) { this.chaser.matrix.copy(mat4(R_c, r_c)); this.chaser.matrixWorldNeedsUpdate = true; }

  /** Render the chaser camera (position, OpenCV axes in LVLH) and return RGBA pixels, top row first. */
  renderFlightCamera(camPos, R_cam) {
    // three.js camera axes: x = x_cv, y = -y_cv, z = -z_cv
    const R3 = R_cam.map((row) => [row[0], -row[1], -row[2]]);
    this.flightCam.matrixWorld.copy(mat4(R3, camPos));
    this.flightCam.matrixWorldInverse.copy(this.flightCam.matrixWorld).invert();
    const W = this.camModel.width, H = this.camModel.height;
    this.chaser.visible = false; this.overlay.visible = false; this.stars.visible = true;
    this.renderer.setRenderTarget(this.target_rt);
    this.renderer.render(this.scene, this.flightCam);
    this.renderer.readRenderTargetPixels(this.target_rt, 0, 0, W, H, this.pixels);
    this.renderer.setRenderTarget(null);
    this.chaser.visible = true; this.overlay.visible = true;
    for (let y = 0; y < H; y++) this.rgba.set(this.pixels.subarray((H - 1 - y) * W * 4, (H - y) * W * 4), y * W * 4);
    return this.rgba;
  }

  renderView(width, height) {
    const s = this.renderer.getSize(new THREE.Vector2());
    if (s.x !== width || s.y !== height) { this.renderer.setSize(width, height, false); this.viewCam.aspect = width / height; this.viewCam.updateProjectionMatrix(); }
    this.renderer.render(this.scene, this.viewCam);
  }
}
