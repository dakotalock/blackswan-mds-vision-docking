// Page wiring: scenarios, the animation loop, the camera view with detections drawn on, live telemetry, chart, CSV.

import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { detectMarker, toGray } from "./aruco.js";
import { mul, mulVec, v3 } from "./linalg.js";
import { Mission, TELEMETRY_COLUMNS } from "./mission.js";
import { CameraModel, project } from "./pose.js";
import { DockingScene } from "./scene.js";

const $ = (id) => document.getElementById(id);

async function loadData() {
  if (window.__APP_DATA) return window.__APP_DATA;           // the encrypted build carries its data inside
  const [cal, mdsCsv, mdsSummary] = await Promise.all([
    fetch("data/calibration.json").then((r) => r.json()),
    fetch("data/mds_run.csv").then((r) => r.text()),
    fetch("data/mds_summary.json").then((r) => r.json()),
  ]);
  return { cal, mdsCsv, mdsSummary };
}

function parseCsv(text) {
  const [head, ...lines] = text.trim().split("\n");
  const cols = head.split(",");
  return lines.map((l) => Object.fromEntries(l.split(",").map((v, i) => [cols[i], v === "" || v === "nan" ? NaN : isNaN(+v) ? v : +v])));
}

const data = await loadData();
const cal = data.cal;
const mdsRows = parseCsv(data.mdsCsv);
const mds = data.mdsSummary;
const mdsStart = [mdsRows[0].rx_true, mdsRows[0].ry_true, mdsRows[0].rz_true];

const SCENARIOS = [
  { id: "replay", name: "Same start as the MDS run (10 m)", opts: { x0: mdsStart, visionPeriod: 4 }, seed: 2,
    desc: "Starts from the exact position the chaser had at the beginning of the docking run inside MDS, camera frame every 4 s. The grey dashed lines on the chart are that MDS run." },
  { id: "nominal", name: "Random start, 10 m", opts: { startRange: 10, visionPeriod: 4 }, seed: 7,
    desc: "10 m out along the docking axis with a random lateral offset and pointing error (change the seed for a different one)." },
  { id: "dropout", name: "Fault: camera dropout 30–70 s", opts: { startRange: 10, visionPeriod: 4, dropout: [30, 70] }, seed: 5,
    desc: "The camera goes dark for 40 s. The safety monitor sees the navigation fix is stale, aborts, backs off to 12 m, waits for the camera and tries again." },
  { id: "misfire", name: "Fault: thruster misfire at 20 s", opts: { startRange: 10, visionPeriod: 4, misfire: [20, [0.08, 0, 0.05]] }, seed: 4,
    desc: "One second of unwanted thrust knocks the chaser sideways. The filter rejects then re-accepts the camera, the monitor aborts on the corridor, and the approach is flown again." },
  { id: "far", name: "Longer approach, 14 m", opts: { startRange: 14, visionPeriod: 3 }, seed: 11,
    desc: "The Python demo's default: 14 m out, a camera frame every 3 s. At this range the marker is under 35 px, so the first fixes use position only." },
];

// ---------------------------------------------------------------- scene and camera
const view = $("view"), camCanvas = $("cam"), camCtx = camCanvas.getContext("2d");
let mission;
const scene = new DockingScene(view, cal, new CameraModel(cal));
const controls = new OrbitControls(scene.viewCam, view);
controls.target.set(0, -9, 0); controls.enableDamping = true; controls.update();

let lastImage = null;
function camera(camPos, R_cam) {
  const rgba = scene.renderFlightCamera(camPos, R_cam);
  const det = detectMarker(toGray(rgba, 640, 480), 640, 480);
  lastImage = new ImageData(new Uint8ClampedArray(rgba), 640, 480);
  return { corners: det ? det.corners : null };
}

function drawCamera(frame) {
  if (!lastImage) return;
  camCtx.putImageData(lastImage, 0, 0);
  if (frame.dropout) { camCtx.fillStyle = "rgba(0,0,0,0.7)"; camCtx.fillRect(0, 0, 640, 480); }
  const pose = frame.pose, K = mission.cam.K;
  if (pose && !frame.dropout) {
    const o = pose.tct, P = (p) => project(K, p);
    const axes = [[1, 0, 0, "#ff3b30"], [0, 1, 0, "#34c759"], [0, 0, 1, "#0a84ff"]];   // target frame axes, 1 m
    const po = P(o);
    camCtx.lineWidth = 3;
    for (const [x, y, z, c] of axes) {
      const e = P(v3.add(o, mulVec(pose.Rct, [x, y, z])));
      camCtx.strokeStyle = c; camCtx.beginPath(); camCtx.moveTo(po[0], po[1]); camCtx.lineTo(e[0], e[1]); camCtx.stroke();
    }
    const port = P(v3.add(mulVec(pose.Rct, mission.target.portTarget), o));
    camCtx.strokeStyle = "#ffe600"; camCtx.lineWidth = 2;
    camCtx.beginPath(); camCtx.arc(port[0], port[1], 10, 0, 2 * Math.PI); camCtx.stroke();
  }
  const hud = `T+${String(Math.round(frame.t)).padStart(4)}s  ${mission.guidance.phase}  nav sigma ${(mission.nav.posSigma * 100).toFixed(1)} cm  ` +
    (frame.dropout ? "CAMERA DROPOUT" : pose ? pose.source : "no fix");
  camCtx.fillStyle = "rgba(10,10,10,0.9)"; camCtx.fillRect(0, 480 - 26, 640, 26);
  camCtx.fillStyle = "#e6e6e6"; camCtx.font = "14px ui-monospace, Menlo, monospace"; camCtx.fillText(hud, 8, 480 - 8);
  $("camInfo").textContent = pose && !frame.dropout ? `marker ${pose.markerPx.toFixed(0)} px · reproj ${pose.reprojPx.toFixed(2)} px` : frame.dropout ? "dropout" : "marker not in view";
}

// ---------------------------------------------------------------- chart
const chart = $("chart"), cctx = chart.getContext("2d");
let series = [];
function drawChart() {
  const dpr = Math.min(window.devicePixelRatio || 1, 2), w = chart.clientWidth, h = chart.clientHeight;
  if (chart.width !== w * dpr) { chart.width = w * dpr; chart.height = h * dpr; }
  cctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  cctx.clearRect(0, 0, w, h);
  const L = 34, R = 8, T = 6, B = 18, tMax = Math.max(120, ...series.map((s) => s.t), mission.opts.x0 ? 110 : 0);
  const X = (t) => L + ((w - L - R) * t) / tMax, lo = -2.3, hi = 1.3;
  const Y = (v) => T + ((h - T - B) * (hi - Math.log10(Math.max(v, 10 ** lo)))) / (hi - lo);
  cctx.font = "10px ui-monospace, Menlo, monospace"; cctx.fillStyle = "#8b9bb8"; cctx.strokeStyle = "#1e2a44"; cctx.lineWidth = 1;
  for (const [v, lab] of [[10, "10 m"], [1, "1 m"], [0.1, "10 cm"], [0.01, "1 cm"]]) {
    cctx.beginPath(); cctx.moveTo(L, Y(v)); cctx.lineTo(w - R, Y(v)); cctx.stroke(); cctx.fillText(lab, 0, Y(v) + 3);
  }
  for (let t = 0; t <= tMax; t += tMax > 300 ? 100 : 20) cctx.fillText(`${t}`, X(t) - 6, h - 4);
  const line = (pts, color, dash = []) => {
    cctx.strokeStyle = color; cctx.setLineDash(dash); cctx.lineWidth = 1.5; cctx.beginPath();
    pts.forEach(([t, v], i) => (i ? cctx.lineTo(X(t), Y(v)) : cctx.moveTo(X(t), Y(v)))); cctx.stroke(); cctx.setLineDash([]);
  };
  if (mission.opts.x0) {
    line(mdsRows.map((r) => [r.t, r.range_true]), "#64748b", [4, 3]);
    line(mdsRows.map((r) => [r.t, r.nav_err_m]), "#64748b", [2, 3]);
  }
  line(series.map((s) => [s.t, s.range]), "#38bdf8");
  line(series.map((s) => [s.t, s.sigma]), "#a3a3a3", [2, 2]);
  line(series.map((s) => [s.t, s.nav]), "#fbbf24");
  cctx.fillStyle = "#a78bfa";
  for (const s of series) if (Number.isFinite(s.meas)) { cctx.beginPath(); cctx.arc(X(s.t), Y(s.meas), 2.5, 0, 2 * Math.PI); cctx.fill(); }
}

// ---------------------------------------------------------------- telemetry table, events, stats
const tbody = $("tele").querySelector("tbody"), wrap = $("teleWrap");
const fmt = (v, d) => (Number.isFinite(v) ? v.toFixed(d) : "—");
function addTelemetry(row) {
  const r = Object.fromEntries(TELEMETRY_COLUMNS.map((c, i) => [c, row[i]]));
  const tr = document.createElement("tr");
  tr.className = `new ${r.phase}${r.fix ? " fix" : ""}`;
  for (const cell of [fmt(r.t, 0), r.phase, fmt(r.range_true, 2), fmt(r.nav_err_m * 100, 1), fmt(r.nav_sigma_m * 100, 1),
    fmt(r.meas_err_m * 100, 1), fmt(r.axis_err_deg, 2), r.fix || "", fmt(r.dv_mps, 3)]) {
    const td = document.createElement("td"); td.textContent = cell; tr.appendChild(td);
  }
  tbody.appendChild(tr);
  if ($("follow").checked) wrap.scrollTop = wrap.scrollHeight;
}

let shownEvents = 0;
function addEvent(t, kind, text) {
  const li = document.createElement("li");
  li.className = kind;
  li.innerHTML = `<b>T+${Math.round(t)} s</b>`;
  li.append(`${kind}: ${text}`);
  $("events").appendChild(li);
  $("events").scrollTop = $("events").scrollHeight;
}

function setPhase(text, cls) { const p = $("phase"); p.textContent = text; p.className = `pill ${cls}`; }

function updateStats(out) {
  const x = out.xTrue;
  $("clock").textContent = `T+${Math.round(mission.t)} s`;
  $("range").textContent = `${v3.norm(x.slice(0, 3)).toFixed(2)} m`;
  $("rate").textContent = `${(-v3.dot(x.slice(3), mission.axisL) * 100).toFixed(1)} cm/s`;          // speed toward the port, along its axis
  $("dv").textContent = `${mission.dv.toFixed(3)} m/s`;
  $("navErr").textContent = `${(out.navErr * 100).toFixed(1)} cm`;
  $("axisErr").textContent = `${out.axisErr.toFixed(2)}°`;
  if (out.frame && Number.isFinite(out.frame.measErr)) $("measErr").textContent = `${(out.frame.measErr * 100).toFixed(1)} cm`;
  $("navPill").textContent = `nav 1σ ${(mission.nav.posSigma * 100).toFixed(1)} cm`;
  const ph = mission.guidance.phase;
  setPhase(ph === "ABORT" ? "ABORT · RETREAT" : mission.guidance.committed ? "FINAL · COMMITTED" : "APPROACH", ph === "ABORT" ? "bad" : mission.guidance.committed ? "warn" : "ok");
}

function showResult() {
  const s = mission.summary(), d = s.docked, m = mds.docked;
  const rows = [
    ["outcome", d ? (d.ok ? "soft capture" : "hard contact") : "no contact", m.ok ? "soft capture" : "hard contact"],
    ["contact time", d ? `${d.t} s` : "—", `${m.t} s`],
    ["off the port axis", d ? `${(d.lateral_miss_m * 100).toFixed(1)} cm` : "—", `${(m.lateral_miss_m * 100).toFixed(1)} cm`],
    ["contact speed", d ? `${(d.contact_speed_mps * 100).toFixed(1)} cm/s` : "—", `${(m.contact_speed_mps * 100).toFixed(1)} cm/s`],
    ["Δv used", `${s.delta_v_mps.toFixed(3)} m/s`, `${mds.delta_v_mps.toFixed(3)} m/s`],
    ["camera frames / fixes", `${s.frames} / ${s.vision_fixes}`, `${mds.mds_frames} / ${mds.vision_fixes}`],
    ["camera fix error, mean / max", `${(s.measurement_error_m.mean * 100).toFixed(1)} / ${(s.measurement_error_m.max * 100).toFixed(1)} cm`,
      `${(mds.measurement_error_m.mean * 100).toFixed(1)} / ${(mds.measurement_error_m.max * 100).toFixed(1)} cm`],
  ];
  $("cmp").innerHTML = "";
  for (const r of rows) { const tr = document.createElement("tr"); r.forEach((c) => { const td = document.createElement("td"); td.textContent = c; tr.appendChild(td); }); $("cmp").appendChild(tr); }
  $("resultCard").hidden = false;
  if (d) addEvent(d.t, d.ok ? "DOCK" : "HARD", `${d.ok ? "soft capture" : "hard contact"}, ${(d.lateral_miss_m * 100).toFixed(1)} cm off the port axis at ${(d.contact_speed_mps * 100).toFixed(1)} cm/s`);
  else addEvent(mission.t, "HARD", "mission time limit reached without docking");
  setPhase(d?.ok ? "DOCKED" : "NOT DOCKED", d?.ok ? "ok" : "bad");
}

// ---------------------------------------------------------------- run control
let running = false, acc = 0, lastTs = 0;
function currentScenario() { return SCENARIOS.find((s) => s.id === $("scenario").value); }

function reset() {
  const sc = currentScenario();
  mission = new Mission(cal, { ...sc.opts, seed: +$("seed").value || 0 }, camera);
  series = []; shownEvents = 0; tbody.innerHTML = ""; $("events").innerHTML = ""; $("resultCard").hidden = true;
  scene.resetPaths();
  running = false; $("run").textContent = "▶ Run"; $("run").disabled = false;
  const s0 = mission.ownState(); scene.setChaser(s0.r_c, s0.R_c);
  // show the first camera frame straight away
  const R_cam = mul(s0.R_c, mission.cam.R_body_cam);
  camera(v3.add(s0.r_c, mulVec(s0.R_c, mission.cam.offsetBody)), R_cam);
  drawCamera({ t: 0, pose: null, dropout: false });
  $("camInfo").textContent = "ready";
  setPhase("READY", "ok"); $("clock").textContent = "T+0 s";
  for (const id of ["range", "rate", "dv", "navErr", "measErr", "axisErr"]) $(id).textContent = "—";
  $("navPill").textContent = `nav 1σ ${(mission.nav.posSigma * 100).toFixed(0)} cm`;
  drawChart();
}

function stepOnce() {
  const out = mission.step();
  if (!out) return;
  addTelemetry(out.row);
  series.push({ t: out.row[0], range: out.row[2], nav: out.navErr, sigma: mission.nav.posSigma, meas: out.frame?.measErr });
  scene.pushPath(scene.truePath, v3.add(mission.portT, out.xTrue.slice(0, 3)));
  scene.pushPath(scene.estPath, v3.add(mission.portT, out.navX.slice(0, 3)));
  const s = mission.ownState(); scene.setChaser(s.r_c, s.R_c);
  if (out.frame) drawCamera(out.frame);
  const ev = mission.guidance.events;
  while (shownEvents < ev.length) { const [t, k, why] = ev[shownEvents++]; addEvent(t, k, why); }
  updateStats(out);
  if (mission.done) { running = false; $("run").textContent = "▶ Run"; showResult(); }
}

function frame(ts) {
  const dtWall = Math.min(0.25, (ts - (lastTs || ts)) / 1000); lastTs = ts;
  if (running) {
    acc += dtWall * +$("speed").value;
    const t0 = performance.now();
    while (acc >= 1 && running && performance.now() - t0 < 40) { stepOnce(); acc -= 1; }
    if (acc > 5) acc = 5;
    drawChart();
  }
  controls.update();
  scene.renderView(view.clientWidth, view.clientHeight);
  requestAnimationFrame(frame);
}

$("run").onclick = () => {
  if (mission.done) reset();
  running = !running; acc = running ? 1 : 0;
  $("run").textContent = running ? "❚❚ Pause" : "▶ Run";
};
$("reset").onclick = reset;
$("csv").onclick = () => {
  const blob = new Blob([mission.csv()], { type: "text/csv" });
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `telemetry_${currentScenario().id}_seed${mission.opts.seed}.csv`;
  document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
};
for (const s of SCENARIOS) { const o = document.createElement("option"); o.value = s.id; o.textContent = s.name; $("scenario").appendChild(o); }
$("scenario").onchange = () => { const sc = currentScenario(); $("seed").value = sc.seed; $("scDesc").textContent = sc.desc; reset(); };
$("seed").onchange = reset;
$("scDesc").textContent = SCENARIOS[0].desc;
window.addEventListener("resize", drawChart);
reset();
requestAnimationFrame(frame);
window.__mission = () => mission;                             // for automated checks
