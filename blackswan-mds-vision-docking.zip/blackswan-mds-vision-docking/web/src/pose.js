// Camera and target models, and the pose of the target from the marker's four corners.
// Port of CameraModel / FiducialTarget / pose_from_corners in examples/utilities/util_vision_nav.py.
// OpenCV's SOLVEPNP_IPPE_SQUARE + solvePnPRefineLM is replaced by the same idea in plain JavaScript:
//   1. a homography from the marker plane to the image gives one pose (Zhang's decomposition);
//   2. a small planar marker has a second, mirror-image pose: the plane normal reflected about the line of sight;
//   3. both are refined by Levenberg-Marquardt on the corner reprojection error (the same cost OpenCV minimises),
//      so both land on the same two minima that OpenCV returns.

import { fromColumns, inv, lstsq, mul, mulVec, orthonormalize, rotvec, transpose, v3 } from "./linalg.js";

export class CameraModel {
  constructor(cal = {}) {
    this.width = 640; this.height = 480; this.focalLengthMm = 20.7; this.sensorWidthMm = 36.0;
    this.offsetBody = cal.cam_offset_body ?? [0, 0, 0];
    this.focalScale = cal.focal_scale ?? 1.0;
    // camera axes in the chaser body frame: x_c = -Z_b, y_c = +Y_b, z_c = +X_b (boresight)
    let Rbc = fromColumns([0, 0, -1], [0, 1, 0], [1, 0, 0]);
    if (cal.camera_mount_rotvec) Rbc = mul(rotvec(cal.camera_mount_rotvec), Rbc);
    this.R_body_cam = Rbc;
    const f = (this.focalLengthMm / this.sensorWidthMm) * this.width * this.focalScale;
    this.K = [[f, 0, (this.width - 1) / 2], [0, f, (this.height - 1) / 2], [0, 0, 1]];
  }
}

export class FiducialTarget {
  constructor(cal = {}) {
    this.markerId = 3;
    this.sideM = cal.marker_side_m ?? 1.0;
    this.centerTarget = cal.marker_center_target ?? [0, 0, 0];
    this.R_target_marker = cal.R_target_marker ?? [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
    this.portTarget = [0, 0, 3.18];
    this.portAxisTarget = [0, 0, 1];
  }

  /** Marker corners in the marker frame, ArUco order: top-left, top-right, bottom-right, bottom-left. */
  objectPoints() {
    const h = this.sideM / 2;
    return [[-h, h, 0], [h, h, 0], [h, -h, 0], [-h, -h, 0]];
  }
}

/** Pinhole projection (camera frame -> pixels). */
export function project(K, p) {
  return [K[0][0] * (p[0] / p[2]) + K[0][2], K[1][1] * (p[1] / p[2]) + K[1][2]];
}

const transform = (R, t, p) => v3.add(mulVec(R, p), t);

function residuals(K, obj, px, R, t) {
  const r = [];
  for (let i = 0; i < obj.length; i++) {
    const p = transform(R, t, obj[i]);
    if (p[2] <= 1e-6) return null;
    const q = project(K, p);
    r.push(q[0] - px[i][0], q[1] - px[i][1]);
  }
  return r;
}
const sumsq = (r) => r.reduce((s, x) => s + x * x, 0);

/** Levenberg-Marquardt on the reprojection error (rotation as a small left rotation vector + translation). */
function refineLM(K, obj, px, R, t) {
  let res = residuals(K, obj, px, R, t);
  if (!res) return null;
  let lambda = 1e-3;
  for (let iter = 0; iter < 100; iter++) {
    const J = res.map(() => new Array(6).fill(0));
    for (let k = 0; k < 6; k++) {
      const eps = k < 3 ? 1e-7 : 1e-7 * Math.max(1, v3.norm(t));
      const d = [0, 0, 0, 0, 0, 0]; d[k] = eps;
      const dm = [0, 0, 0, 0, 0, 0]; dm[k] = -eps;
      const rp = residuals(K, obj, px, mul(rotvec(d.slice(0, 3)), R), v3.add(t, d.slice(3)));
      const rm = residuals(K, obj, px, mul(rotvec(dm.slice(0, 3)), R), v3.add(t, dm.slice(3)));
      if (!rp || !rm) return null;
      for (let i = 0; i < res.length; i++) J[i][k] = (rp[i] - rm[i]) / (2 * eps);
    }
    const Jt = transpose(J), JtJ = mul(Jt, J), g = mulVec(Jt, res);
    let improved = false;
    for (let tries = 0; tries < 10 && !improved; tries++) {
      const A = JtJ.map((row, i) => row.map((a, j) => (i === j ? a * (1 + lambda) + 1e-12 : a)));
      let step;
      try { step = mulVec(inv(A), g).map((s) => -s); } catch { return { R, t, res }; }
      const R2 = orthonormalize(mul(rotvec(step.slice(0, 3)), R)), t2 = v3.add(t, step.slice(3));
      const r2 = residuals(K, obj, px, R2, t2);
      if (r2 && sumsq(r2) < sumsq(res)) {
        const gain = sumsq(res) - sumsq(r2);
        R = R2; t = t2; res = r2; lambda = Math.max(lambda / 10, 1e-12); improved = true;
        if (gain < 1e-20 || Math.hypot(...step) < 1e-13) return { R, t, res };
      } else lambda *= 10;
    }
    if (!improved) break;
  }
  return { R, t, res };
}

/** Both poses of a planar square (marker frame -> camera frame), refined. */
export function planarPoseCandidates(K, obj, px) {
  // homography: marker plane (X, Y) -> normalised image coordinates
  const A = [], b = [];
  for (let i = 0; i < 4; i++) {
    const [X, Y] = obj[i];
    const x = (px[i][0] - K[0][2]) / K[0][0], y = (px[i][1] - K[1][2]) / K[1][1];
    A.push([X, Y, 1, 0, 0, 0, -x * X, -x * Y]); b.push(x);
    A.push([0, 0, 0, X, Y, 1, -y * X, -y * Y]); b.push(y);
  }
  let h;
  try { h = lstsq(A, b); } catch { return []; }
  const h1 = [h[0], h[3], h[6]], h2 = [h[1], h[4], h[7]], h3 = [h[2], h[5], 1];
  let lam = 2 / (v3.norm(h1) + v3.norm(h2));
  if (h3[2] * lam < 0) lam = -lam;                     // the marker is in front of the camera
  const r1 = v3.scale(h1, lam), r2 = v3.scale(h2, lam);
  const R0 = orthonormalize(fromColumns(r1, r2, v3.cross(r1, r2)));
  const t0 = v3.scale(h3, lam);
  const first = refineLM(K, obj, px, R0, t0);
  if (!first) return [];
  // the mirror-image pose: reflect the marker normal about the line of sight to the marker centre
  const los = v3.unit(first.t);
  const n1 = [first.R[0][2], first.R[1][2], first.R[2][2]];
  const n2 = v3.sub(v3.scale(los, 2 * v3.dot(los, n1)), n1);
  const ax = v3.cross(n1, n2), s = v3.norm(ax), c = v3.dot(n1, n2);
  const flip = s < 1e-12 ? [[1, 0, 0], [0, 1, 0], [0, 0, 1]] : rotvec(v3.scale(ax, Math.atan2(s, c) / s));
  const second = refineLM(K, obj, px, mul(flip, first.R), first.t);
  return [first, second].filter(Boolean);
}

/**
 * Target pose in the camera frame (p_cam = R_ct p_target + t_ct) from the marker's corners (ArUco order).
 * A small planar marker seen from afar has two nearly equally good poses (mirror-image tilts). Both are computed;
 * the one whose docking axis agrees with the navigation prior (priorAxisCam) is kept, or the lower-reprojection one
 * when there is no prior. Below minAttitudePx the marker's tilt is too uncertain: only its position is used and the
 * attitude comes from the prior (priorRct): "position-only" mode.
 */
export function poseFromCorners(c, cam, target, priorAxisCam = null, priorRct = null, minAttitudePx = 35.0) {
  const obj = target.objectPoints();
  const cands = planarPoseCandidates(cam.K, obj, c).map(({ R, t, res }) => {
    const reproj = Math.sqrt(sumsq(res) / 4);
    const Rct = mul(R, transpose(target.R_target_marker));
    const tct = v3.sub(t, mulVec(Rct, target.centerTarget));
    const axis = mulVec(Rct, target.portAxisTarget);
    return { Rct, tct, reproj, agree: priorAxisCam ? v3.dot(axis, priorAxisCam) : 0 };
  });
  if (!cands.length) return null;
  let best = cands[0];
  for (const k of cands.slice(1)) {
    if (priorAxisCam ? k.agree - 0.02 * k.reproj > best.agree - 0.02 * best.reproj : k.reproj < best.reproj) best = k;
  }
  let { Rct, tct } = best;
  let source = "marker";
  const size = c.reduce((sum, p, i) => sum + Math.hypot(p[0] - c[(i + 3) % 4][0], p[1] - c[(i + 3) % 4][1]), 0) / 4;
  if (size < minAttitudePx && priorRct) {
    const markerC = v3.add(mulVec(Rct, target.centerTarget), tct);   // marker centre (well determined even when tiny)
    Rct = priorRct;
    tct = v3.sub(markerC, mulVec(Rct, target.centerTarget));
    source = "marker (position only)";
  }
  return { Rct, tct, reprojPx: best.reproj, source, markerPx: size };
}

