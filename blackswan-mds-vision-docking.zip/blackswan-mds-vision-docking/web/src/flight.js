// Flight software: a line-by-line port of examples/utilities/util_vision_nav.py (frames, the Clohessy-Wiltshire
// Kalman filter, guidance with its safety monitor). tests/web_parity.mjs checks it against the Python numbers.

import { diag, eye, inv, mul, mulVec, transpose, v3, zeros } from "./linalg.js";

// ------------------------------------------------------------------ frames
/** Rows are the LVLH axes (x radial, y along-track, z orbit normal) in the inertial frame: p_lvlh = R p_inertial. */
export function lvlhRotation(r, v) {
  const x = v3.unit(r), z = v3.unit(v3.cross(r, v)), y = v3.cross(z, x);
  return [x, y, z];
}

export const meanMotion = (r, mu = 3.986004418e14) => Math.sqrt(mu / v3.norm(r) ** 3);

/** MDS's util_attitude.get_rot_x_aligned: body +X along v1, body +Y along v1 x v2 (a body-to-world matrix). */
export function xAligned(v1, v2) {
  const x = v3.unit(v1), y = v3.unit(v3.cross(x, v3.unit(v2))), z = v3.cross(x, y);
  return [0, 1, 2].map((i) => [x[i], y[i], z[i]]);
}

// ------------------------------------------------------------------ relative navigation filter
export function cwStm(n, t) {
  const s = Math.sin(n * t), c = Math.cos(n * t), nt = n * t;
  return [
    [4 - 3 * c, 0, 0, s / n, (2 * (1 - c)) / n, 0],
    [6 * (s - nt), 1, 0, (2 * (c - 1)) / n, (4 * s - 3 * nt) / n, 0],
    [0, 0, c, 0, 0, s / n],
    [3 * n * s, 0, 0, c, 2 * s, 0],
    [6 * n * (c - 1), 0, 0, -2 * s, 4 * c - 3, 0],
    [0, 0, -n * s, 0, 0, c],
  ];
}

/** x_{k+1} = F x_k + B a over dt with constant acceleration a. */
export function cwPropagate(n, x, a, dt) {
  const xf = mulVec(cwStm(n, dt), x);
  return xf.map((xi, i) => xi + (i < 3 ? 0.5 * dt * dt * a[i] : dt * a[i - 3]));
}

/** State: chaser docking port relative to the target docking port, in the target's LVLH frame [m, m/s]. */
export class RelNavFilter {
  constructor(n, x0, posSigma, velSigma, accelNoise = 2e-4) {
    this.n = n;
    this.x = x0.slice();
    this.P = diag([posSigma ** 2, posSigma ** 2, posSigma ** 2, velSigma ** 2, velSigma ** 2, velSigma ** 2]);
    this.q = accelNoise ** 2;
    this.rejections = 0;
  }

  predict(dt, accel) {
    const F = cwStm(this.n, dt);
    this.x = cwPropagate(this.n, this.x, accel, dt);
    const q = this.q, Q = zeros(6, 6);
    for (let i = 0; i < 3; i++) {
      Q[i][i] = (q * dt ** 3) / 3;
      Q[i][i + 3] = Q[i + 3][i] = (q * dt ** 2) / 2;
      Q[i + 3][i + 3] = q * dt;
    }
    this.P = mul(mul(F, this.P), transpose(F)).map((row, i) => row.map((p, j) => p + Q[i][j]));
  }

  /** Kalman update with innovation gating. Three rejections in a row mean the filter, not the sensor, is wrong
   *  (an unmodelled push, say): the position covariance is re-inflated so the measurement can pull it back. */
  updatePosition(z, sigma, gate = 5.0) {
    const S = () => [0, 1, 2].map((i) => [0, 1, 2].map((j) => this.P[i][j] + (i === j ? sigma ** 2 : 0)));
    const y = [0, 1, 2].map((i) => z[i] - this.x[i]);
    let Sm = S();
    if (v3.dot(y, mulVec(inv(Sm), y)) > gate ** 2 * 3) {
      this.rejections += 1;
      if (this.rejections < 3) return false;
      for (let i = 0; i < 3; i++) { this.P[i][i] += y[i] ** 2 + sigma ** 2; this.P[i + 3][i + 3] += 0.02 ** 2; }
      Sm = S();
    }
    this.rejections = 0;
    const Si = inv(Sm);
    const K = this.P.map((row) => [0, 1, 2].map((j) => row[0] * Si[0][j] + row[1] * Si[1][j] + row[2] * Si[2][j]));   // P H^T S^-1
    this.x = this.x.map((xi, i) => xi + K[i][0] * y[0] + K[i][1] * y[1] + K[i][2] * y[2]);
    const IKH = eye(6).map((row, i) => row.map((e, j) => (j < 3 ? e - K[i][j] : e)));
    const P = mul(IKH, this.P);
    this.P = P.map((row, i) => row.map((p, j) => 0.5 * (p + P[j][i])));
    return true;
  }

  get posSigma() { return Math.sqrt(this.P[0][0] + this.P[1][1] + this.P[2][2]); }
}

/** Natural relative acceleration (gravity gradient + Coriolis) the controller cancels. */
export const cwAccel = (x, n) => [3 * n * n * x[0] + 2 * n * x[4], -2 * n * x[3], -n * n * x[2]];

// ------------------------------------------------------------------ guidance with a safety monitor
const round1 = (t) => Math.round(t * 10) / 10;

/** Straight-line approach along the target's docking axis, slowing as it closes, with automatic aborts. */
export class Guidance {
  constructor(opts = {}) {
    Object.assign(this, {
      corridorDeg: 10.0, keepOutM: 15.0, finalSpeed: 0.03, maxSpeed: 0.2, maxAccel: 0.01, retreatToM: 12.0,
      lostLockS: 12.0, commitRangeM: 3.0, commitSigmaM: 0.05, commitCoastS: 90.0,
    }, opts);
    this.phase = "APPROACH";
    this.events = [];
    this.committed = false;
  }

  /** Acceleration command in LVLH. x: chaser port relative to target port (LVLH), axis: the target's docking
   *  axis (pointing out of the port, toward the chaser's side). */
  command(t, x, axis, n, sinceFix, posSigma = 1.0) {
    const r = x.slice(0, 3), v = x.slice(3);
    const along = v3.dot(r, axis);
    const lateral = v3.sub(r, v3.scale(axis, along));
    const offAxis = (Math.atan2(v3.norm(lateral), Math.max(along, 1e-6)) * 180) / Math.PI;
    const rng = v3.norm(r);
    if (this.phase === "APPROACH") {
      if (rng < this.keepOutM && offAxis > this.corridorDeg && rng > 1.0) {
        this.event(t, "ABORT", `outside the approach corridor (${offAxis.toFixed(1)} deg)`);
      } else if (sinceFix > this.lostLockS && rng < this.keepOutM) {
        const committed = rng < this.commitRangeM && posSigma < this.commitSigmaM + 0.002 * sinceFix;
        if (!committed) this.event(t, "ABORT", `no navigation fix for ${sinceFix.toFixed(0)} s`);
        else if (sinceFix > this.commitCoastS) this.event(t, "ABORT", `final approach coasted ${sinceFix.toFixed(0)} s without a fix`);
        else if (!this.committed) {
          this.committed = true;
          this.events.push([round1(t), "COMMITTED", `marker out of view at ${rng.toFixed(1)} m; finishing on inertial navigation`]);
        }
      }
    }
    if (this.phase === "ABORT" && along > this.retreatToM && sinceFix < 3)
      this.event(t, "APPROACH", "safe hold reached and target re-acquired: approaching again");
    let vCmd;
    if (this.phase === "APPROACH") {
      const speed = Math.min(Math.max(0.02 * along + this.finalSpeed, this.finalSpeed), this.maxSpeed);
      vCmd = v3.sub(v3.scale(axis, -speed), v3.scale(lateral, 0.05));
    } else {                                           // ABORT: back away along the axis
      vCmd = v3.sub(v3.scale(axis, 0.1), v3.scale(lateral, 0.03));
    }
    const a = v3.sub(v3.scale(v3.sub(vCmd, v), 0.2), cwAccel(x, n));
    const na = v3.norm(a);
    return na <= this.maxAccel ? a : v3.scale(a, this.maxAccel / na);
  }

  event(t, phase, why) {
    this.phase = phase;
    this.events.push([round1(t), phase, why]);
  }
}
